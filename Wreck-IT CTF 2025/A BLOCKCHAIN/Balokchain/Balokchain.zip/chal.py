import json
import subprocess
from pathlib import Path
from typing import Optional

from eth_account import Account

import sandbox
from web3 import HTTPProvider, Web3

def set_balance(web3: Web3, account_address: str, amount: int):
    res = web3.provider.make_request(
        "anvil_setBalance",
        [account_address, amount]
    )


def deploy(web3: Web3, deployer_address: str, deployer_privateKey: str, player_address: str) -> str:
    uri = web3.provider.endpoint_uri
    contract_info = json.loads(Path("compiled/Setup.sol/Setup.json").read_text())
    abi = contract_info["abi"]
    bytecode = contract_info["bytecode"]["object"]


    contract = web3.eth.contract(abi=abi, bytecode=bytecode)

    construct_txn = contract.constructor(player_address).build_transaction(
        {
            "from": deployer_address,
            "nonce": web3.eth.get_transaction_count(deployer_address),
            "value": Web3.to_wei(10, 'ether')
        }
    )

    tx_create = web3.eth.account.sign_transaction(construct_txn, deployer_privateKey)
    tx_hash = web3.eth.send_raw_transaction(tx_create.raw_transaction)

    rcpt = web3.eth.wait_for_transaction_receipt(tx_hash)

	set_balance(web3, deployer_address, Web3.to_wei(0.2, 'ether'))
    set_balance(web3, player_address, Web3.to_wei(10, 'ether'))

    return rcpt.contractAddress

def pre_tx_hook(data, node_info):
    """
    Executed before a transaction is processed.
    Returns:
        - status: HTTP status code (e.g., 200 for success, 400 for error)
        - msg: Message to be returned in the response in case of non 2xx status
    """

    return 200, ""

def post_tx_hook(data, response, node_info):
    """
    Executed after a transaction is processed.
    Returns:
        - status: HTTP status code (e.g., 200 for success, 400 for error)
        - msg: Message to be returned in the response in case of non 2xx status
    """

    mnemonic = node_info.seed
    deployer_account = Account.from_mnemonic(mnemonic, account_path="m/44'/60'/0'/0/0")

    deployer_address = deployer_account.address

    rpc_url = f"http://127.0.0.1:{node_info.port}"
    setup_addr = node_info.contract_addr
    web3 = Web3(HTTPProvider(rpc_url))

    setup_contract_info = json.loads(Path("compiled/Setup.sol/Setup.json").read_text())
    setup_contract = web3.eth.contract(address=setup_addr, abi=setup_contract_info["abi"])

    rollup_addr = setup_contract.functions.rollup().call()

    rollup_contract_info = json.loads(Path("compiled/IRollup.sol/IRollup.json").read_text())
    rollup_contract = web3.eth.contract(address=rollup_addr, abi=rollup_contract_info["abi"])

    if web3.eth.block_number > 300:
        return 403, "Challenge ended"

    try:
        txn = rollup_contract.functions.postNonRegistrationBlock(
            b"\x00" * 32,
            0,
            0,
            b"\x00" * 16,
            [b"\x00" * 32, b"\x00" * 32],
            [b"\x00" * 32, b"\x00" * 32, b"\x00" * 32, b"\x00" * 32],
            [
            bytes.fromhex("266edd38e735d530340ee0cf1928ac83fed0e24ca7897af4f23ee6dea4d16251"),
            bytes.fromhex("0edfbe763843ca71b6cbd671e4e9fcf28aaad97991be96490e38b39f123fc9cd"),
            bytes.fromhex("186b0447aff3de646775301e14002f09a752aecf2f700747429538637eb4c3f8"),
            bytes.fromhex("1dac1fd3f4881bd6b6c07c833cce4d921d4aa0478fd2a51c609e7056d4713b72"),
            ],
            b"\x00" * 32,
            b""
        ).build_transaction(
            {
            "from": deployer_address,
            "nonce": web3.eth.get_transaction_count(deployer_address),
            "value": Web3.to_wei("0.01", "ether"),
            }
        )

        tx_create = web3.eth.account.sign_transaction(txn, deployer_account.key)
        tx_hash = web3.eth.send_raw_transaction(tx_create.raw_transaction)
    except Exception:
        pass

    return 200, ""

def begin_block_hook(node_info, block):
    """
    Executed after a block is mined
    """

    return 200, ""

app = sandbox.run_launcher(
    deploy,
    pre_tx_hook=pre_tx_hook,
    post_tx_hook=post_tx_hook,
    begin_block_hook=begin_block_hook
)
