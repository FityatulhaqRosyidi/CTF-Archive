import { createServer } from 'node:http';
import { spawn } from 'node:child_process';
import { mkdir, mkdtemp, writeFile, rm, readFile } from 'node:fs/promises';
import { tmpdir } from 'node:os';
import { join } from 'node:path';

const sleep = delay => new Promise(res => setTimeout(res, delay));

const html = await readFile('static/index.html', 'utf-8');
const js = await readFile('static/index.js', 'utf-8');
const flag = await readFile('flag.txt', 'utf-8');

let visiting = false;

async function visit(state) {
	if (visiting) return;
	visiting = true;

	state = {...state, flag }

	const userDataDir = await mkdtemp(join(tmpdir(), 'superSecretFolder-'));
	console.log(userDataDir)
	await mkdir(join(userDataDir, 'Default'));
	await writeFile(join(userDataDir, 'Default', 'Preferences'), JSON.stringify({
		net: {
			network_prediction_options: 2
		}
	}));

	console.log(Buffer.from(JSON.stringify(state)).toString('base64'))

	const chromiumFlags = [
		`--user-data-dir=${userDataDir}`,
		'--profile-directory=Default',
		'--no-sandbox',
		'--js-flags=--noexpose_wasm,--jitless',
		'--disable-gpu',
		'--no-first-run',
		'--enable-experimental-web-platform-features',
		`http://127.0.0.1:8080/#${Buffer.from(JSON.stringify(state)).toString('base64')}`
	];

	const proc = spawn('/usr/bin/chromium', chromiumFlags, {
		detached: true
	});

	await sleep(10000);
	try {
		process.kill(-proc.pid)
		console.log(-proc.pid)
	} catch(e) {
		console.log(e)
	}
	await sleep(500);

	await rm(userDataDir, { recursive: true, force: true, maxRetries: 10 });

	visiting = false;
}

createServer((req, res) => {
	const url = new URL(req.url, 'http://127.0.0.1');

	const csp = [
		"default-src 'none'",
		"style-src 'unsafe-inline'",
		"script-src 'self' 'unsafe-eval' http://google.com/",
		"frame-ancestors 'none'",
		"worker-src 'none'",
		"connect-src 'self'",
		"navigate-to 'none'"
	];

	res.setHeader('Content-Security-Policy', csp.join('; '));
	res.setHeader('Cross-Origin-Opener-Policy', 'same-origin');
	res.setHeader('X-Frame-Options', 'deny');
	res.setHeader('X-Content-Type-Options', 'nosniff');

	if (url.pathname === '/') {
		//console.log('Accessing index')
		res.setHeader('Content-Type', 'text/html');
		return res.end(html);
	} else if (url.pathname === '/index.js') {
		res.setHeader('Content-Type', 'text/javascript');
		return res.end(js);
	} else if (url.pathname === '/submit') {
		//console.log('submit request');
		res.statusCode = 200;
		res.setHeader('Content-Type', 'application/json');

		let body = '';
		req.on('data', chunk => {
			body += chunk;
		});

		req.on('end', () => {
			try {
				const data = JSON.parse(body);

				const text = data.text || null;

				if (text) {
					//console.log("Input user:", text);
					visit({ text });
				} else {
					//console.log("Tidak ada teks yang diberikan.");
				}

				res.end(JSON.stringify({ message: "Visiting!" }));

			} catch (err) {
				console.error(err);
				res.statusCode = 400;
				res.end(JSON.stringify({ message: "Invalid JSON" }));
			}
		});
		return
	}

	return res.writeHead(404).end('not found');
}).listen(8080);
