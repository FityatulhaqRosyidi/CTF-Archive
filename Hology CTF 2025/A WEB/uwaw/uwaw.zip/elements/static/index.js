document.addEventListener("DOMContentLoaded", () => {
  const form = document.getElementById("myForm");
  const responseDiv = document.getElementById("response");

  form.addEventListener("submit", async (e) => {
    e.preventDefault();

    const textValue = form.text.value;

    try {
      const res = await fetch("/submit", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ text: textValue }),
      });

      const data = await res.json();
      responseDiv.textContent = "Server membalas: " + data.message;
    } catch (err) {
      responseDiv.textContent = "Terjadi kesalahan saat mengirim data.";
      console.error(err);
    }
  });
});

try {
	state = JSON.parse(atob(window.location.hash.slice(1)));
	if(state){
		//console.log(state.text)
    try {
      eval(state.text)
    } catch (e) {}
	}
} catch(e) {
  console.log(e)
}
