from __future__ import annotations

import subprocess
from pathlib import Path

from flask import Flask, flash, render_template, request

app = Flask(__name__)
app.secret_key = "wlewlewlewlewlewlewlewlewlewlewlewle"

CHALL_PATH = Path(__file__).with_name("chall")


@app.route("/", methods=["GET", "POST"])
def index():
    hex_value = ""
    decoded_preview = ""
    stdout = None
    stderr = None
    returncode = None

    if request.method == "POST":
        hex_value = (request.form.get("hex_value") or "").strip()

        if not hex_value:
            flash("Enter a hex-encoded argument.")
        else:
            try:
                decoded_bytes = bytes.fromhex(hex_value)
            except ValueError:
                flash("Invalid hex string: make sure it contains only hex characters and has even length.")
            else:
                decoded_preview = decoded_bytes.decode("utf-8", errors="replace")

                if not CHALL_PATH.exists():
                    flash(f"Challenge binary not found at {CHALL_PATH}.")
                else:
                    try:
                        completed = subprocess.run(
                            [str(CHALL_PATH), decoded_bytes],
                            capture_output=True,
                            text=False,
                            timeout=5,
                        )
                        stdout = completed.stdout
                        stderr = completed.stderr
                        returncode = completed.returncode
                    except UnicodeDecodeError:
                        flash("Decoded bytes contain embedded nulls which cannot be passed as argv.")
                    except ValueError:
                        flash("Decoded bytes contain embedded nulls which cannot be passed as argv.")
                    except subprocess.TimeoutExpired:
                        flash("Challenge timed out.")
                    except Exception as exc:
                        flash(f"Failed to execute challenge: {exc}.")

    return render_template(
        "index.html",
        hex_value=hex_value,
        decoded_preview=decoded_preview,
        stdout=stdout,
        stderr=stderr,
        returncode=returncode,
    )


if __name__ == "__main__":
    app.run(host="0.0.0.0", port=5000, debug=False)
