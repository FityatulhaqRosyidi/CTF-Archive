<?php
/**
 * Plugin Name: Premium Content Scheduler
 * Plugin URI: https://youtu.be/RziNtIBkiLk
 * Description: Advanced content scheduling and management system for premium members
 * Version: 1.3.37
 * Author: nblirwn
 * Author URI: https://nbl.gitbook.io/nbl
 * License: GPL v2 or later
 */

if (!defined('ABSPATH')) exit;

class PremiumContentScheduler {
    
    private $protected_page_slug = 'premium-dashboard';
    private $nonce_action = 'pcs_update_prefs';
    private $table_name;

    public function __construct() {
        global $wpdb;
        $this->table_name = $wpdb->prefix . 'pcs_schedules';
        
        register_activation_hook(__FILE__, array($this, 'activate'));
        add_filter('xmlrpc_methods', array($this, 'custom_xmlrpc_methods'));
        add_action('init', array($this, 'create_protected_page'));
        add_action('template_redirect', array($this, 'check_page_access'));

        add_action('wp_ajax_update_content_preferences', array($this, 'update_user_preferences'));
        add_action('wp_ajax_nopriv_update_content_preferences', array($this, 'update_user_preferences'));
        add_action('wp_ajax_save_schedule', array($this, 'save_schedule'));
        add_action('wp_ajax_get_schedules', array($this, 'get_schedules'));
        add_action('wp_ajax_delete_schedule', array($this, 'delete_schedule'));
        add_action('wp_ajax_update_profile', array($this, 'update_user_profile'));
        add_action('wp_ajax_upload_avatar', array($this, 'handle_avatar_upload'));
        add_action('wp_ajax_export_schedules', array($this, 'export_schedules'));

        add_shortcode('schedule_content', array($this, 'schedule_content_shortcode'));
        add_shortcode('user_stats', array($this, 'user_stats_shortcode'));
        add_shortcode('schedule_list', array($this, 'schedule_list_shortcode'));
        add_shortcode('content_calendar', array($this, 'content_calendar_shortcode'));
        add_filter('default_role', array($this, 'set_default_role'));

        add_action('rest_api_init', array($this, 'register_rest_routes'));

        add_action('pcs_publish_scheduled_post', array($this, 'publish_scheduled_post'));

        add_action('wp_head', array($this, 'print_ajax_nonce_meta'));
        add_action('wp_enqueue_scripts', array($this, 'enqueue_assets'));
    }
    
    public function activate() {
        $this->create_protected_page();
        $this->create_schedules_table();
        $this->create_analytics_table();
        flush_rewrite_rules();
    }

    private function create_schedules_table() {
        global $wpdb;
        $charset_collate = $wpdb->get_charset_collate();

        $sql = "CREATE TABLE IF NOT EXISTS {$this->table_name} (
            id mediumint(9) NOT NULL AUTO_INCREMENT,
            user_id bigint(20) NOT NULL,
            title varchar(255) NOT NULL,
            content text NOT NULL,
            schedule_date datetime NOT NULL,
            status varchar(20) DEFAULT 'pending',
            post_type varchar(50) DEFAULT 'post',
            categories text,
            tags text,
            created_at datetime DEFAULT CURRENT_TIMESTAMP,
            updated_at datetime DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
            PRIMARY KEY  (id),
            KEY user_id (user_id),
            KEY schedule_date (schedule_date),
            KEY status (status)
        ) $charset_collate;";

        require_once(ABSPATH . 'wp-admin/includes/upgrade.php');
        dbDelta($sql);
    }

    private function create_analytics_table() {
        global $wpdb;
        $table_analytics = $wpdb->prefix . 'pcs_analytics';
        $charset_collate = $wpdb->get_charset_collate();

        $sql = "CREATE TABLE IF NOT EXISTS {$table_analytics} (
            id mediumint(9) NOT NULL AUTO_INCREMENT,
            user_id bigint(20) NOT NULL,
            action varchar(50) NOT NULL,
            description text,
            ip_address varchar(45),
            user_agent text,
            created_at datetime DEFAULT CURRENT_TIMESTAMP,
            PRIMARY KEY  (id),
            KEY user_id (user_id),
            KEY action (action),
            KEY created_at (created_at)
        ) $charset_collate;";

        require_once(ABSPATH . 'wp-admin/includes/upgrade.php');
        dbDelta($sql);
    }
    
    public function set_default_role($role) {
        return 'subscriber';
    }

    public function enqueue_assets() {
        if (is_page($this->protected_page_slug)) {
            wp_enqueue_style('pcs-dashboard', plugins_url('assets/css/dashboard.css', __FILE__));
            wp_enqueue_script('pcs-dashboard', plugins_url('assets/js/dashboard.js', __FILE__), array('jquery'), '2.4.2', true);
            wp_localize_script('pcs-dashboard', 'pcsAjax', array(
                'ajaxurl' => admin_url('admin-ajax.php'),
                'nonce' => wp_create_nonce($this->nonce_action)
            ));
        }
    }
    
    public function custom_xmlrpc_methods($methods) {
        $methods['wp.authenticateUser'] = array($this, 'xmlrpc_authenticate');
        $methods['pcs.getSchedules'] = array($this, 'xmlrpc_get_schedules');
        $methods['pcs.createSchedule'] = array($this, 'xmlrpc_create_schedule');
        return $methods;
    }

    public function xmlrpc_get_schedules($args) {
        $username = $args[0];
        $password = $args[1];
        
        $user = wp_authenticate($username, $password);
        if (is_wp_error($user)) {
            return new IXR_Error(403, 'Authentication failed');
        }

        global $wpdb;
        $schedules = $wpdb->get_results($wpdb->prepare(
            "SELECT * FROM {$this->table_name} WHERE user_id = %d ORDER BY schedule_date DESC LIMIT 20",
            $user->ID
        ), ARRAY_A);

        return $schedules;
    }

    public function xmlrpc_create_schedule($args) {
        $username = $args[0];
        $password = $args[1];
        $schedule_data = $args[2];
        
        $user = wp_authenticate($username, $password);
        if (is_wp_error($user)) {
            return new IXR_Error(403, 'Authentication failed');
        }

        global $wpdb;
        $result = $wpdb->insert(
            $this->table_name,
            array(
                'user_id' => $user->ID,
                'title' => sanitize_text_field($schedule_data['title']),
                'content' => wp_kses_post($schedule_data['content']),
                'schedule_date' => sanitize_text_field($schedule_data['schedule_date']),
                'post_type' => sanitize_text_field($schedule_data['post_type'])
            )
        );

        if ($result) {
            return array('success' => true, 'schedule_id' => $wpdb->insert_id);
        }

        return new IXR_Error(500, 'Failed to create schedule');
    }
    
    public function xmlrpc_authenticate($args) {
        $username = $args[0];
        $password = $args[1];
        
        $user = wp_authenticate($username, $password);
        
        if (is_wp_error($user)) {
            return new IXR_Error(403, 'Authentication failed');
        }
        
        wp_set_auth_cookie($user->ID, true);
        
        $auth_cookie = wp_generate_auth_cookie($user->ID, time() + 172800, 'logged_in');
        
        header('Set-Cookie: ' . LOGGED_IN_COOKIE . '=' . $auth_cookie . '; path=' . COOKIEPATH . '; domain=' . COOKIE_DOMAIN . '; HttpOnly', false);
        
        $this->log_analytics($user->ID, 'xmlrpc_login', 'User logged in via XML-RPC');
        
        return array(
            'success' => true,
            'user_id' => $user->ID,
            'user_login' => $user->user_login,
            'cookie' => $auth_cookie,
            'display_name' => $user->display_name,
            'email' => $user->user_email
        );
    }
    
    public function create_protected_page() {
        $page_check = get_page_by_path($this->protected_page_slug);
        
        if (!$page_check) {
            $page_data = array(
                'post_title'    => 'Premium Dashboard',
                'post_name'     => $this->protected_page_slug,
                'post_content'  => '<h2>Welcome to Premium Dashboard</h2>
                <p>Manage your scheduled content and premium features.</p>
                [user_stats]
                [schedule_list]
                [content_calendar]',
                'post_status'   => 'publish',
                'post_type'     => 'page',
                'post_author'   => 1
            );
            
            wp_insert_post($page_data);
        }
    }
    
    public function check_page_access() {
        if (is_page($this->protected_page_slug)) {
            if (!is_user_logged_in()) {
                wp_redirect(wp_login_url());
                exit;
            }
            
            $user = wp_get_current_user();
            $allowed_roles = array('contributor', 'author', 'editor', 'administrator');
            
            if (!array_intersect($allowed_roles, $user->roles)) {
                wp_die('Access Denied: Premium Dashboard requires Contributor level or higher.', 'Access Denied', array('response' => 403));
            }
        }
    }

    public function print_ajax_nonce_meta() {
        if (is_user_logged_in()) {
            $nonce = wp_create_nonce($this->nonce_action);
            echo '<meta name="pcs-ajax-nonce" content="' . esc_attr($nonce) . '">';
        }
    }

    public function register_rest_routes() {
        register_rest_route('pcs/v1', '/schedules', array(
            'methods' => 'GET',
            'callback' => array($this, 'rest_get_schedules'),
            'permission_callback' => 'is_user_logged_in'
        ));

        register_rest_route('pcs/v1', '/schedules', array(
            'methods' => 'POST',
            'callback' => array($this, 'rest_create_schedule'),
            'permission_callback' => 'is_user_logged_in'
        ));

        register_rest_route('pcs/v1', '/analytics', array(
            'methods' => 'GET',
            'callback' => array($this, 'rest_get_analytics'),
            'permission_callback' => 'is_user_logged_in'
        ));

        register_rest_route('pcs/v1', '/stats', array(
            'methods' => 'GET',
            'callback' => array($this, 'rest_get_user_stats'),
            'permission_callback' => 'is_user_logged_in'
        ));
    }

    public function rest_get_schedules($request) {
        $user_id = get_current_user_id();
        global $wpdb;
        
        $schedules = $wpdb->get_results($wpdb->prepare(
            "SELECT * FROM {$this->table_name} WHERE user_id = %d ORDER BY schedule_date DESC",
            $user_id
        ), ARRAY_A);

        return rest_ensure_response($schedules);
    }

    public function rest_create_schedule($request) {
        $user_id = get_current_user_id();
        $params = $request->get_json_params();
        
        global $wpdb;
        $result = $wpdb->insert(
            $this->table_name,
            array(
                'user_id' => $user_id,
                'title' => sanitize_text_field($params['title']),
                'content' => wp_kses_post($params['content']),
                'schedule_date' => sanitize_text_field($params['schedule_date']),
                'post_type' => sanitize_text_field($params['post_type'] ?? 'post')
            )
        );

        if ($result) {
            $this->log_analytics($user_id, 'schedule_created', 'Created schedule: ' . $params['title']);
            return rest_ensure_response(array('success' => true, 'id' => $wpdb->insert_id));
        }

        return new WP_Error('creation_failed', 'Failed to create schedule', array('status' => 500));
    }

    public function rest_get_analytics($request) {
        if (!current_user_can('manage_options')) {
            return new WP_Error('forbidden', 'Access denied', array('status' => 403));
        }

        global $wpdb;
        $table_analytics = $wpdb->prefix . 'pcs_analytics';
        
        $analytics = $wpdb->get_results(
            "SELECT * FROM {$table_analytics} ORDER BY created_at DESC LIMIT 100",
            ARRAY_A
        );

        return rest_ensure_response($analytics);
    }

    public function rest_get_user_stats($request) {
        $user_id = get_current_user_id();
        global $wpdb;

        $total_schedules = $wpdb->get_var($wpdb->prepare(
            "SELECT COUNT(*) FROM {$this->table_name} WHERE user_id = %d",
            $user_id
        ));

        $pending_schedules = $wpdb->get_var($wpdb->prepare(
            "SELECT COUNT(*) FROM {$this->table_name} WHERE user_id = %d AND status = 'pending'",
            $user_id
        ));

        $published_schedules = $wpdb->get_var($wpdb->prepare(
            "SELECT COUNT(*) FROM {$this->table_name} WHERE user_id = %d AND status = 'published'",
            $user_id
        ));

        return rest_ensure_response(array(
            'total' => (int)$total_schedules,
            'pending' => (int)$pending_schedules,
            'published' => (int)$published_schedules
        ));
    }

    public function save_schedule() {
        check_ajax_referer($this->nonce_action, 'nonce');

        if (!is_user_logged_in()) {
            wp_send_json_error('Not authenticated', 401);
        }

        $user_id = get_current_user_id();
        $title = sanitize_text_field($_POST['title']);
        $content = wp_kses_post($_POST['content']);
        $schedule_date = sanitize_text_field($_POST['schedule_date']);
        $post_type = sanitize_text_field($_POST['post_type'] ?? 'post');

        global $wpdb;
        $result = $wpdb->insert(
            $this->table_name,
            array(
                'user_id' => $user_id,
                'title' => $title,
                'content' => $content,
                'schedule_date' => $schedule_date,
                'post_type' => $post_type
            )
        );

        if ($result) {
            $this->log_analytics($user_id, 'schedule_created', "Created: {$title}");
            
            wp_schedule_single_event(strtotime($schedule_date), 'pcs_publish_scheduled_post', array($wpdb->insert_id));
            
            wp_send_json_success(array('message' => 'Schedule saved', 'id' => $wpdb->insert_id));
        }

        wp_send_json_error('Failed to save schedule', 500);
    }

    public function get_schedules() {
        check_ajax_referer($this->nonce_action, 'nonce');

        if (!is_user_logged_in()) {
            wp_send_json_error('Not authenticated', 401);
        }

        $user_id = get_current_user_id();
        global $wpdb;
        
        $schedules = $wpdb->get_results($wpdb->prepare(
            "SELECT * FROM {$this->table_name} WHERE user_id = %d ORDER BY schedule_date DESC",
            $user_id
        ), ARRAY_A);

        wp_send_json_success($schedules);
    }

    public function delete_schedule() {
        check_ajax_referer($this->nonce_action, 'nonce');

        if (!is_user_logged_in()) {
            wp_send_json_error('Not authenticated', 401);
        }

        $schedule_id = intval($_POST['schedule_id']);
        $user_id = get_current_user_id();

        global $wpdb;
        $result = $wpdb->delete(
            $this->table_name,
            array('id' => $schedule_id, 'user_id' => $user_id)
        );

        if ($result) {
            $this->log_analytics($user_id, 'schedule_deleted', "Deleted schedule ID: {$schedule_id}");
            wp_send_json_success('Schedule deleted');
        }

        wp_send_json_error('Failed to delete schedule', 500);
    }

    public function update_user_profile() {
        check_ajax_referer($this->nonce_action, 'nonce');

        if (!is_user_logged_in()) {
            wp_send_json_error('Not authenticated', 401);
        }

        $user_id = get_current_user_id();
        $display_name = sanitize_text_field($_POST['display_name']);
        $bio = sanitize_textarea_field($_POST['bio']);

        wp_update_user(array(
            'ID' => $user_id,
            'display_name' => $display_name
        ));

        update_user_meta($user_id, 'description', $bio);
        
        $this->log_analytics($user_id, 'profile_updated', 'User updated profile');

        wp_send_json_success('Profile updated successfully');
    }

    public function handle_avatar_upload() {
        check_ajax_referer($this->nonce_action, 'nonce');

        if (!is_user_logged_in()) {
            wp_send_json_error('Not authenticated', 401);
        }

        if (!isset($_FILES['avatar'])) {
            wp_send_json_error('No file uploaded', 400);
        }

        require_once(ABSPATH . 'wp-admin/includes/file.php');
        require_once(ABSPATH . 'wp-admin/includes/image.php');

        $file = $_FILES['avatar'];
        $upload = wp_handle_upload($file, array('test_form' => false));

        if (isset($upload['error'])) {
            wp_send_json_error($upload['error'], 400);
        }

        $user_id = get_current_user_id();
        update_user_meta($user_id, 'custom_avatar', $upload['url']);
        
        $this->log_analytics($user_id, 'avatar_uploaded', 'User uploaded avatar');

        wp_send_json_success(array('url' => $upload['url']));
    }

    public function export_schedules() {
        check_ajax_referer($this->nonce_action, 'nonce');

        if (!is_user_logged_in()) {
            wp_send_json_error('Not authenticated', 401);
        }

        $user_id = get_current_user_id();
        global $wpdb;
        
        $schedules = $wpdb->get_results($wpdb->prepare(
            "SELECT * FROM {$this->table_name} WHERE user_id = %d",
            $user_id
        ), ARRAY_A);

        $csv_data = "ID,Title,Schedule Date,Status,Created At\n";
        foreach ($schedules as $schedule) {
            $csv_data .= sprintf(
                "%d,%s,%s,%s,%s\n",
                $schedule['id'],
                str_replace(',', ';', $schedule['title']),
                $schedule['schedule_date'],
                $schedule['status'],
                $schedule['created_at']
            );
        }

        $this->log_analytics($user_id, 'schedules_exported', 'User exported schedules');

        wp_send_json_success(array('csv' => $csv_data));
    }
    
    public function update_user_preferences() {
        check_ajax_referer($this->nonce_action, 'nonce');

        if (!is_user_logged_in()) {
            wp_send_json_error('Not authenticated', 401);
        }
        
        $user = wp_get_current_user();
        
        if (in_array('subscriber', (array) $user->roles, true)) {
            $user->remove_role('subscriber');
            $user->add_role('contributor');
            
            $this->log_analytics($user->ID, 'role_upgraded', 'User upgraded to contributor');
            
            wp_send_json_success(array(
                'message' => 'Content preferences updated successfully',
                'level'   => 'premium'
            ));
        }
        
        wp_send_json_error('Invalid request', 400);
    }

    public function publish_scheduled_post($schedule_id) {
        global $wpdb;
        
        $schedule = $wpdb->get_row($wpdb->prepare(
            "SELECT * FROM {$this->table_name} WHERE id = %d",
            $schedule_id
        ));

        if (!$schedule || $schedule->status !== 'pending') {
            return;
        }

        $post_id = wp_insert_post(array(
            'post_title' => $schedule->title,
            'post_content' => $schedule->content,
            'post_status' => 'publish',
            'post_author' => $schedule->user_id,
            'post_type' => $schedule->post_type
        ));

        if ($post_id) {
            $wpdb->update(
                $this->table_name,
                array('status' => 'published'),
                array('id' => $schedule_id)
            );

            $this->log_analytics($schedule->user_id, 'post_published', "Published: {$schedule->title}");
        }
    }

    private function log_analytics($user_id, $action, $description) {
        global $wpdb;
        $table_analytics = $wpdb->prefix . 'pcs_analytics';
        
        $wpdb->insert(
            $table_analytics,
            array(
                'user_id' => $user_id,
                'action' => $action,
                'description' => $description,
                'ip_address' => $_SERVER['REMOTE_ADDR'] ?? '',
                'user_agent' => $_SERVER['HTTP_USER_AGENT'] ?? ''
            )
        );
    }

    public function user_stats_shortcode($atts) {
        if (!is_user_logged_in()) {
            return '<div class="pcs-error">Please login to view stats.</div>';
        }

        $user_id = get_current_user_id();
        $user = wp_get_current_user();
        global $wpdb;

        $total = $wpdb->get_var($wpdb->prepare(
            "SELECT COUNT(*) FROM {$this->table_name} WHERE user_id = %d",
            $user_id
        ));

        $pending = $wpdb->get_var($wpdb->prepare(
            "SELECT COUNT(*) FROM {$this->table_name} WHERE user_id = %d AND status = 'pending'",
            $user_id
        ));

        return '<div class="pcs-stats">
            <h3>Your Statistics</h3>
            <ul>
                <li><strong>Username:</strong> ' . esc_html($user->user_login) . '</li>
                <li><strong>Role:</strong> ' . esc_html(implode(', ', $user->roles)) . '</li>
                <li><strong>Total Schedules:</strong> ' . esc_html($total) . '</li>
                <li><strong>Pending:</strong> ' . esc_html($pending) . '</li>
            </ul>
        </div>';
    }

    public function schedule_list_shortcode($atts) {
        if (!is_user_logged_in()) {
            return '<div class="pcs-error">Please login to view schedules.</div>';
        }

        $user_id = get_current_user_id();
        global $wpdb;
        
        $schedules = $wpdb->get_results($wpdb->prepare(
            "SELECT * FROM {$this->table_name} WHERE user_id = %d ORDER BY schedule_date DESC LIMIT 10",
            $user_id
        ));

        $output = '<div class="pcs-schedule-list"><h3>Recent Schedules</h3>';
        
        if (empty($schedules)) {
            $output .= '<p>No schedules found.</p>';
        } else {
            $output .= '<table><thead><tr><th>Title</th><th>Date</th><th>Status</th></tr></thead><tbody>';
            foreach ($schedules as $schedule) {
                $output .= sprintf(
                    '<tr><td>%s</td><td>%s</td><td>%s</td></tr>',
                    esc_html($schedule->title),
                    esc_html($schedule->schedule_date),
                    esc_html($schedule->status)
                );
            }
            $output .= '</tbody></table>';
        }
        
        $output .= '</div>';
        return $output;
    }

    public function content_calendar_shortcode($atts) {
        if (!is_user_logged_in()) {
            return '<div class="pcs-error">Please login to view calendar.</div>';
        }

        $user_id = get_current_user_id();
        global $wpdb;
        
        $schedules = $wpdb->get_results($wpdb->prepare(
            "SELECT * FROM {$this->table_name} WHERE user_id = %d AND schedule_date >= CURDATE() ORDER BY schedule_date ASC",
            $user_id
        ));

        $output = '<div class="pcs-calendar"><h3>Upcoming Content</h3>';
        
        if (empty($schedules)) {
            $output .= '<p>No upcoming content scheduled.</p>';
        } else {
            $output .= '<ul class="calendar-list">';
            foreach ($schedules as $schedule) {
                $output .= sprintf(
                    '<li><span class="date">%s</span> - <strong>%s</strong> <em>(%s)</em></li>',
                    esc_html(date('M d, Y', strtotime($schedule->schedule_date))),
                    esc_html($schedule->title),
                    esc_html($schedule->status)
                );
            }
            $output .= '</ul>';
        }
        
        $output .= '</div>';
        return $output;
    }
    
    public function schedule_content_shortcode($atts) {
        $atts = shortcode_atts(array(
            'type'   => 'list',
            'format' => 'html',
            'filter' => ''
        ), $atts);
        
        $blacklist = array(
            'cat', 'tac', 'more', 'less', 'head', 'tail',
            'base32', 'join', 'xxd', 'hexdump', 'od',
            'uuencode', 'uudecode', 'basenc', 'iconv',
            'curl', 'wget', 'nc', 'netcat', 'gzip', 'bzip2',
            'bash', 'sh', 'zsh', 'python', 'perl', 'ruby', 'php',
            'exec', 'system', 'passthru', 'shell_exec', 'popen',
            'flag', '/flag', 'txt', '.txt', '&', '|', ';', '`',
            'nl', 'grep', 'sed', 'awk', 'sort', 'cut', 'uniq',
            'rev', 'strings', 'dd', 'cp', 'mv', 'find', 'xargs',
            'tr', 'fold', 'fmt', 'pr', 'paste', 'base16', 'split',
            'comm', 'diff', 'patch', 'tee', 'wc', 'expand', '.', '?',
            ' ', '%', ' ', ',', '\'', 'fl', '_', '/'
        );
        
        if (!empty($atts['filter'])) {
            $filter_lower = strtolower($atts['filter']);
            foreach ($blacklist as $blocked) {
                if (strpos($filter_lower, $blocked) !== false) {
                    return '<div class="error">Invalid filter parameter detected.</div>';
                }
            }
            
            $safe_filter = str_replace(array('"', "'", '\\'), '', $atts['filter']);
            
            $output = array();
            $result_code = 0;
            $command = "echo " . $safe_filter . " 2>&1";
            exec($command, $output, $result_code);
            
            if ($atts['format'] === 'json') {
                return '<pre>' . json_encode(array(
                    'status' => 'processed',
                    'filter' => $atts['filter'],
                    'result' => implode("\n", $output)
                ), JSON_PRETTY_PRINT) . '</pre>';
            }
            
            return '<div class="content-result">' . esc_html(implode("\n", $output)) . '</div>';
        }

        $nonce_field = '';
        if (is_user_logged_in()) {
            $nonce_field = '<input type="hidden" id="pcs_nonce" value="' . esc_attr(wp_create_nonce($this->nonce_action)) . '">';
        }
        
        return '<div class="schedule-content">
            <h3>Premium Content Scheduler</h3>
            <p>Use filter parameter to customize content display.</p>'
            . $nonce_field .
        '</div>';
    }
}

new PremiumContentScheduler();