import numpy
import ipaddress
import requests
from flask import Flask, request, send_from_directory, abort, jsonify
from jinja2.sandbox import SandboxedEnvironment
from functools import wraps

app = Flask(__name__)

env = SandboxedEnvironment()
env.globals["numpy"] = numpy

def internal_only(f):
    @wraps(f)
    def decorated_function(*args, **kwargs):
        client_ip = request.remote_addr

        try:
            ip_obj = ipaddress.ip_address(client_ip)
            if not client_ip == "127.0.0.1":
                abort(403, description="Access denied: external access is not allowed.")
        except ValueError:
            abort(403, description="Access denied: invalid client IP.")

        return f(*args, **kwargs)
    return decorated_function

def whitelist_required(f):
    @wraps(f)
    def decorated_function(*args, **kwargs):
        allowed_chars = set(
            "abcdefghijklmnopqrstuvwxyz"
            "ABCDEFGHIJKLMNOPQRSTUVWXYZ"
            "0123456789"
            " .,{}()[]|:"
        )

        all_values = list(request.args.values()) + list(request.form.values())

        for value in all_values:
            for ch in value:
                if ch not in allowed_chars:
                    abort(400, description=f"Blocked request: disallowed character '{ch}' detected.")

        return f(*args, **kwargs)
    return decorated_function

def send_request(url: str):
    # Yang HCS HCS ajah
    if not url.startswith("http://hcs-team.com") and url.endswith("/blog"):
        abort(400, description="Only URLs starting with 'http://hcs-team.com' are allowed.")

    try:
        requests.get(url, timeout=5)
        return "OK"
    except requests.RequestException as e:
        return "OK"

@app.get("/")
@internal_only
def index():
    return send_from_directory("static", "index.html")

@app.get("/render_sandbox")
@internal_only
@whitelist_required
def render_sandbox():
    content = request.args.get("content", "")
    return env.from_string(content).render()

@app.get("/proxy")
def proxy():
    url = request.args.get("url")
    if not url:
        abort(400, description="Missing 'url' parameter.")
    result = send_request(url)
    return jsonify(result)

if __name__ == "__main__":
    app.run(host="0.0.0.0", port=1337, debug=False)
