document.getElementById("render").addEventListener("click", async () => {
  const content = document.getElementById("content").value;
  const res = await fetch("/render_sandbox?content=" + encodeURIComponent(content));
  const text = await res.text();
  document.getElementById("result").innerHTML = text;
});
