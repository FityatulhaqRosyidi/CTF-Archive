
import torch
import torch.nn as nn
from safetensors.torch import load_model
from safetensors import safe_open
import json

class ObscureNet(nn.Module):
    def __init__(self, vocab_size, embedding_dim=2):
        super().__init__()
        self.e1 = nn.Embedding(vocab_size, embedding_dim)
        self.m1 = nn.Linear(embedding_dim, embedding_dim)
        self.e2 = nn.Embedding(vocab_size, embedding_dim)
        self.m2 = nn.Linear(embedding_dim, embedding_dim)
        hidden_dim = 32
        self.out_l1 = nn.Linear(embedding_dim, hidden_dim)
        self.out_act = nn.ReLU()
        self.out_l2 = nn.Linear(hidden_dim, vocab_size)
        self.sig = nn.Parameter(torch.empty(embedding_dim), requires_grad=False)
        mul_matrix = torch.tensor(
            [[1.0, 0.0, 0.0, -1.0], [0.0, 1.0, 1.0, 0.0]], requires_grad=False
        )
        self.register_buffer("complex_mul_mat", mul_matrix)

    def forward(self, idx1, idx2):
        v1_pre_act = self.m1(self.e1(idx1))
        v2_pre_act = self.m2(self.e2(idx2))
        v1 = (torch.exp(v1_pre_act) - torch.exp(-v1_pre_act)) / (
            torch.exp(v1_pre_act) + torch.exp(-v1_pre_act)
        )
        v2 = (torch.exp(v2_pre_act) - torch.exp(-v2_pre_act)) / (
            torch.exp(v2_pre_act) + torch.exp(-v2_pre_act)
        )
        outer_prod = torch.einsum("...i,...j->...ij", v1, v2)
        flat_outer_prod = outer_prod.flatten(start_dim=-2)
        r_vec = torch.einsum("kj,...j->...k", self.complex_mul_mat, flat_outer_prod)
        t_vec = torch.stack([r_vec, self.sig.expand_as(r_vec)]).sum(dim=0)
        h = self.out_l1(t_vec)
        h = self.out_act(h)
        logits = self.out_l2(h)
        return logits

if __name__ == '__main__':
    try:
        with safe_open("model.safetensors", framework="pt") as f:
            metadata = f.metadata()
        char_to_idx = json.loads(metadata.get('char_to_idx'))
        idx_to_char_str_keys = json.loads(metadata.get('idx_to_char'))
        idx_to_char = {int(k): v for k, v in idx_to_char_str_keys.items()}
        vocab_size = len(char_to_idx)
        print(f"Found metadata! Vocab size: {vocab_size}")
        model = ObscureNet(vocab_size=vocab_size)
        load_model(model, "model.safetensors")
        model.eval()
        print("Model loaded successfully!")
    except FileNotFoundError: 
        print("Error: model.safetensors not found.")
