document.addEventListener("DOMContentLoaded", () => {
  const chatWidget = document.getElementById("chat-widget");
  const chatWidgetBtn = document.getElementById("chat-widget-button");
  const closeChat = document.getElementById("close-chat");
  const chatBox = document.getElementById("chat-box");
  const chatForm = document.getElementById("chat-form");
  const userInput = document.getElementById("user-input");
  const notificationBadge = document.querySelector(".chat-notification-badge");
  const converter = new showdown.Converter();

  // Create toast notification container
  const toastContainer = document.createElement("div");
  toastContainer.id = "toast-container";
  toastContainer.style.cssText = `
    position: fixed;
    top: 24px;
    right: 24px;
    z-index: 10000;
    display: flex;
    flex-direction: column;
    gap: 12px;
  `;
  document.body.appendChild(toastContainer);

  // Toast notification function
  function showToast(message, type = "info") {
    const toast = document.createElement("div");
    toast.style.cssText = `
      background: ${
        type === "success"
          ? "linear-gradient(135deg, #10b981 0%, #059669 100%)"
          : type === "error"
            ? "linear-gradient(135deg, #ef4444 0%, #dc2626 100%)"
            : "linear-gradient(135deg, #6366f1 0%, #8b5cf6 100%)"
      };
      color: white;
      padding: 16px 24px;
      border-radius: 12px;
      box-shadow: 0 8px 32px rgba(0, 0, 0, 0.4);
      border: 1px solid rgba(255, 255, 255, 0.1);
      backdrop-filter: blur(10px);
      font-size: 14px;
      font-weight: 500;
      display: flex;
      align-items: center;
      gap: 10px;
      animation: slideInRight 0.3s cubic-bezier(0.4, 0, 0.2, 1);
      min-width: 300px;
    `;

    const icon = type === "success" ? "✓" : type === "error" ? "✕" : "ℹ";
    toast.innerHTML = `<span style="font-size: 18px;">${icon}</span><span>${message}</span>`;

    toastContainer.appendChild(toast);

    setTimeout(() => {
      toast.style.animation = "slideOutRight 0.3s cubic-bezier(0.4, 0, 0.2, 1)";
      setTimeout(() => toast.remove(), 300);
    }, 3000);
  }

  // Add toast animations to document
  const style = document.createElement("style");
  style.textContent = `
    @keyframes slideInRight {
      from {
        opacity: 0;
        transform: translateX(100px);
      }
      to {
        opacity: 1;
        transform: translateX(0);
      }
    }
    @keyframes slideOutRight {
      from {
        opacity: 1;
        transform: translateX(0);
      }
      to {
        opacity: 0;
        transform: translateX(100px);
      }
    }
    .modal-overlay {
      position: fixed;
      top: 0;
      left: 0;
      right: 0;
      bottom: 0;
      background: rgba(0, 0, 0, 0.7);
      backdrop-filter: blur(5px);
      display: flex;
      align-items: center;
      justify-content: center;
      z-index: 9999;
      animation: fadeIn 0.3s ease;
    }
    .modal {
      background: linear-gradient(135deg, #1e293b 0%, #0f172a 100%);
      border-radius: 20px;
      padding: 32px;
      max-width: 500px;
      width: 90%;
      box-shadow: 0 20px 60px rgba(0, 0, 0, 0.6);
      border: 1px solid rgba(255, 255, 255, 0.1);
      animation: scaleIn 0.3s cubic-bezier(0.4, 0, 0.2, 1);
    }
    .modal h2 {
      color: #e2e8f0;
      font-size: 24px;
      margin-bottom: 16px;
      font-weight: 700;
    }
    .modal p {
      color: #94a3b8;
      line-height: 1.6;
      margin-bottom: 24px;
    }
    .modal-buttons {
      display: flex;
      gap: 12px;
      justify-content: flex-end;
    }
    .modal-btn {
      padding: 12px 24px;
      border: none;
      border-radius: 10px;
      font-weight: 600;
      cursor: pointer;
      transition: all 0.2s;
      font-size: 14px;
    }
    .modal-btn-primary {
      background: linear-gradient(135deg, #6366f1 0%, #8b5cf6 100%);
      color: white;
      box-shadow: 0 4px 12px rgba(99, 102, 241, 0.4);
    }
    .modal-btn-primary:hover {
      transform: translateY(-2px);
      box-shadow: 0 6px 16px rgba(99, 102, 241, 0.6);
    }
    .modal-btn-secondary {
      background: rgba(255, 255, 255, 0.1);
      color: #cbd5e1;
      border: 1px solid rgba(255, 255, 255, 0.1);
    }
    .modal-btn-secondary:hover {
      background: rgba(255, 255, 255, 0.15);
    }
    @keyframes fadeIn {
      from { opacity: 0; }
      to { opacity: 1; }
    }
    @keyframes scaleIn {
      from {
        opacity: 0;
        transform: scale(0.9);
      }
      to {
        opacity: 1;
        transform: scale(1);
      }
    }
  `;
  document.head.appendChild(style);

  // Modal function
  function showModal(title, message) {
    const overlay = document.createElement("div");
    overlay.className = "modal-overlay";

    overlay.innerHTML = `
      <div class="modal">
        <h2>${title}</h2>
        <p>${message}</p>
        <div class="modal-buttons">
          <button class="modal-btn modal-btn-secondary" onclick="this.closest('.modal-overlay').remove()">Close</button>
          <button class="modal-btn modal-btn-primary" onclick="this.closest('.modal-overlay').remove()">Got it!</button>
        </div>
      </div>
    `;

    overlay.addEventListener("click", (e) => {
      if (e.target === overlay) overlay.remove();
    });

    document.body.appendChild(overlay);
  }

  // Smooth scroll for nav links
  document.querySelectorAll(".nav-links a[href^='#']").forEach((link) => {
    link.addEventListener("click", (e) => {
      e.preventDefault();
      const targetId = link.getAttribute("href");

      if (targetId === "#") return;

      const targetSection = document.querySelector(targetId);

      if (targetSection) {
        targetSection.scrollIntoView({
          behavior: "smooth",
          block: "start",
        });
        showToast(`Navigating to ${link.textContent}...`, "info");
      } else {
        showToast(`${link.textContent} section coming soon!`, "info");
      }
    });
  });

  // Login button
  document.querySelector(".btn-login").addEventListener("click", (e) => {
    e.preventDefault();
    showModal(
      "🔐 Login",
      "Our authentication system is currently in development. You'll be able to access your secure dashboard soon with enterprise-grade security features!"
    );
  });

  // Get Started button
  document.querySelector(".btn-primary").addEventListener("click", () => {
    showModal(
      "🚀 Get Started with SecureCloud",
      "Thank you for your interest! Our onboarding process includes a free consultation, custom setup, and dedicated support. A member of our team will reach out to you shortly."
    );
    showToast("Welcome aboard! We'll be in touch soon.", "success");
  });

  // View Demo button
  document.querySelector(".btn-secondary").addEventListener("click", () => {
    showModal(
      "🎥 Schedule a Demo",
      "We'd love to show you SecureCloud in action! Our interactive demo covers infrastructure setup, security features, scaling capabilities, and real-time monitoring. Book a personalized session with our solutions team."
    );
    showToast("Demo request received!", "success");
  });

  // Open chat widget
  chatWidgetBtn.addEventListener("click", () => {
    chatWidget.classList.add("open");
    chatWidgetBtn.style.display = "none";
    userInput.focus();

    // Hide notification badge
    if (notificationBadge) {
      notificationBadge.style.display = "none";
    }
  });

  // Close chat widget
  closeChat.addEventListener("click", () => {
    chatWidget.classList.remove("open");
    chatWidgetBtn.style.display = "flex";
  });

  // Handle quick question buttons
  document.querySelectorAll(".quick-btn").forEach((btn) => {
    btn.addEventListener("click", () => {
      const question = btn.getAttribute("data-question");
      userInput.value = question;
      chatForm.dispatchEvent(new Event("submit"));
    });
  });

  chatForm.addEventListener("submit", async (e) => {
    e.preventDefault();
    const userMessage = userInput.value.trim();
    if (!userMessage) return;

    // Hide quick questions after first message
    const quickQuestions = document.querySelector(".quick-questions");
    if (quickQuestions) {
      quickQuestions.style.display = "none";
    }

    addMessage(userMessage, "user");
    userInput.value = "";

    // Show typing indicator
    const typingIndicator = addTypingIndicator();

    try {
      const response = await fetch("/chat", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify({ message: userMessage }),
      });

      typingIndicator.remove();

      if (!response.ok) {
        throw new Error("Network response was not ok");
      }

      const data = await response.json();
      addMessage(data.response, "bot");
    } catch (error) {
      typingIndicator.remove();
      console.error("Error:", error);
      addMessage(
        "I apologize, but I'm experiencing technical difficulties. Please try again in a moment.",
        "bot"
      );
    }
  });

  function addMessage(message, sender) {
    const messageWrapper = document.createElement("div");
    messageWrapper.style.display = "flex";
    messageWrapper.style.gap = "10px";
    messageWrapper.style.alignItems = "flex-start";
    messageWrapper.style.marginBottom = "12px";

    if (sender === "bot") {
      const avatar = document.createElement("div");
      avatar.textContent = "👩‍💼";
      avatar.style.fontSize = "22px";
      avatar.style.flexShrink = "0";
      messageWrapper.appendChild(avatar);
    }

    const messageElement = document.createElement("div");
    messageElement.classList.add("message", `${sender}-message`);
    const html = converter.makeHtml(message);
    messageElement.innerHTML = html;

    messageWrapper.appendChild(messageElement);

    if (sender === "user") {
      messageWrapper.style.justifyContent = "flex-end";
    }

    chatBox.appendChild(messageWrapper);
    chatBox.scrollTop = chatBox.scrollHeight;
  }

  function addTypingIndicator() {
    const wrapper = document.createElement("div");
    wrapper.style.display = "flex";
    wrapper.style.gap = "10px";
    wrapper.style.alignItems = "flex-start";
    wrapper.style.marginBottom = "12px";
    wrapper.classList.add("typing-indicator-wrapper");

    const avatar = document.createElement("div");
    avatar.textContent = "👩‍💼";
    avatar.style.fontSize = "22px";
    avatar.style.flexShrink = "0";

    const indicator = document.createElement("div");
    indicator.classList.add("message", "bot-message");
    indicator.innerHTML = `
            <div style="display: flex; gap: 4px; align-items: center;">
                <span style="animation: bounce 1.4s infinite; animation-delay: 0s;">●</span>
                <span style="animation: bounce 1.4s infinite; animation-delay: 0.2s;">●</span>
                <span style="animation: bounce 1.4s infinite; animation-delay: 0.4s;">●</span>
            </div>
            <style>
                @keyframes bounce {
                    0%, 60%, 100% { transform: translateY(0); opacity: 0.4; }
                    30% { transform: translateY(-6px); opacity: 1; }
                }
            </style>
        `;

    wrapper.appendChild(avatar);
    wrapper.appendChild(indicator);
    chatBox.appendChild(wrapper);
    chatBox.scrollTop = chatBox.scrollHeight;

    return wrapper;
  }

  // Add particle effect on page load (optional eye candy)
  function createParticle() {
    const particle = document.createElement("div");
    particle.style.cssText = `
      position: fixed;
      width: 4px;
      height: 4px;
      background: radial-gradient(circle, rgba(139, 92, 246, 0.8) 0%, transparent 70%);
      border-radius: 50%;
      pointer-events: none;
      z-index: 1;
      animation: float ${3 + Math.random() * 3}s ease-in-out infinite;
      left: ${Math.random() * 100}vw;
      top: ${Math.random() * 100}vh;
      opacity: ${0.2 + Math.random() * 0.3};
    `;
    document.body.appendChild(particle);

    const floatStyle = document.createElement("style");
    floatStyle.textContent = `
      @keyframes float {
        0%, 100% { transform: translateY(0px) translateX(0px); }
        25% { transform: translateY(-20px) translateX(10px); }
        50% { transform: translateY(-10px) translateX(-10px); }
        75% { transform: translateY(-30px) translateX(5px); }
      }
    `;
    document.head.appendChild(floatStyle);
  }

  // Create some ambient particles
  for (let i = 0; i < 15; i++) {
    setTimeout(() => createParticle(), i * 200);
  }
});
