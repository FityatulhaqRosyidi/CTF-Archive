
from flask import Flask, request, jsonify
import torch
import hashlib
import os
from challenge import ObscureNet
from safetensors.torch import load_model

app = Flask(__name__)

# These MUST be set via environment variables
KEY = os.getenv("ENCRYPTION_KEY")
INTERNAL_KEY = os.getenv("INTERNAL_KEY")
ALPHABET = os.getenv("ALPHABET")

if not KEY or not INTERNAL_KEY or not ALPHABET:
    raise ValueError("Missing required environment variables: ENCRYPTION_KEY, INTERNAL_KEY, ALPHABET")

char_to_idx = {char: i for i, char in enumerate(ALPHABET)}
idx_to_char = {i: char for i, char in enumerate(ALPHABET)}
DIFFICULTY = 6

print("Loading encryption model...")
model = ObscureNet(vocab_size=len(ALPHABET))
load_model(model, "model.safetensors")
model.eval()
print("Model loaded. Service ready.")

def check_pow(solution, challenge):
    h = hashlib.sha256((solution + challenge).encode()).hexdigest()
    return h.startswith('0' * DIFFICULTY)

@app.route('/encrypt', methods=['POST'])
def encrypt():
    data = request.json
    
    if not data:
        return jsonify({"error": "No JSON data provided"}), 400
    
    internal_key = data.get('internal_key')
    pow_solution = data.get('pow_solution')
    pow_challenge = data.get('pow_challenge')
    plaintext = data.get('plaintext')
    
    if not plaintext:
        return jsonify({"error": "No plaintext provided"}), 400
    
    # Internal service-to-service auth OR public PoW
    if internal_key == INTERNAL_KEY:
        pass
    elif pow_solution and pow_challenge:
        if not check_pow(pow_solution, pow_challenge):
            return jsonify({"error": "Invalid proof of work"}), 403
    else:
        return jsonify({"error": "Authentication required"}), 401
    
    if not all(c in ALPHABET for c in plaintext):
        return jsonify({"error": f"Invalid characters"}), 400
    
    try:
        with torch.no_grad():
            text_indices = torch.tensor([char_to_idx[c] for c in plaintext], dtype=torch.long)
            key_indices = torch.tensor([char_to_idx[KEY[i % len(KEY)]] for i in range(len(plaintext))], dtype=torch.long)
            logits = model(text_indices, key_indices)
            output_indices = torch.argmax(logits, dim=1)
            ciphertext = "".join([idx_to_char[idx.item()] for idx in output_indices])
        
        return jsonify({"ciphertext": ciphertext})
    except Exception as e:
        return jsonify({"error": f"Encryption failed: {str(e)}"}), 500

@app.route('/challenge', methods=['GET'])
def get_challenge():
    """Generate a proof-of-work challenge for public API access"""
    challenge = os.urandom(8).hex()
    return jsonify({
        "challenge": challenge,
        "difficulty": DIFFICULTY,
        "instruction": f"Find X such that SHA256(X + '{challenge}') starts with {'0' * DIFFICULTY}"
    })

@app.route('/health', methods=['GET'])
def health():
    return jsonify({"status": "ok", "service": "neural-encryption-api"})

if __name__ == "__main__":
    app.run(host="0.0.0.0", port=1337, debug=False)
