from flask import Flask, request, render_template, jsonify
import os
import requests

app = Flask(__name__)

ALLOWED_DOMAIN = "https://ctf.cert.unlp.edu.ar"
flag = os.environ.get('FLAG', 'flag{fakeflag}')

@app.route('/')
def index():
    return render_template('index.html')

@app.route('/send_flag', methods=['POST'])
def send_flag():
    target_domain = request.form.get('domain', '')
    if not target_domain.startswith(ALLOWED_DOMAIN):
        return jsonify({"error": "Invalid URL"}), 400

    try:
        result = transmit_flag(target_domain)
        return jsonify({
            "success": "Flag sent irreversibly!",
            "domain": target_domain,
            "response": result
        })
    except Exception as e:
        return jsonify({"error": f"Error during transmission: {e}"}), 500


def transmit_flag(url):
    """Pretend to send the flag somewhere you can never get it back."""
    global flag
    data = {"domain": url}
    response = requests.post(
        f"{url}/irreversible_receiver",
        verify=False,
        allow_redirects=False,
        json=data,
        headers={"Flag": flag}
    )
    return "Transmission complete — flag lost forever."


if __name__ == '__main__':
    app.run(debug=False, host="0.0.0.0", port=1337)
