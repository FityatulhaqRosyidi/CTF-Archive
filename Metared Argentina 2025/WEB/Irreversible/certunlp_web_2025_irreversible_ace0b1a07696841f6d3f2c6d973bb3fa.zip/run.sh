#!/bin/bash

docker build -t certunlp-web-irreversible .
docker run -it --rm -p 1337:1337 --name certunlp-web-irreversible certunlp-web-irreversible