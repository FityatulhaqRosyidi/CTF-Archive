from flask import Flask, request, session, redirect, url_for, render_template, g, abort, flash
from werkzeug.security import generate_password_hash, check_password_hash
import sqlite3
import os
import bleach
from bot import Bot
from flask_limiter import Limiter
from flask_limiter.util import get_remote_address

app = Flask(__name__)
app_key = os.urandom(32).hex()
app.secret_key = os.environ.get('FLASK_SECRET', app_key)
limiter = Limiter(
    get_remote_address,
    app=app,
    default_limits=["120 per minute"], 
    storage_uri="memory://",
)

DB_PATH = os.environ.get('DATABASE_PATH', '/tmp/notes.db')


def get_db():
    if 'db' not in g:
        g.db = sqlite3.connect(DB_PATH)
        g.db.row_factory = sqlite3.Row 
    return g.db


@app.teardown_appcontext
def close_db(exc):
    db = g.pop('db', None)
    if db is not None:
        db.close()


def query_one(query, params=()):
    db = get_db()
    cur = db.execute(query, params)
    res = cur.fetchone()
    cur.close()
    return dict(res) if res else None


def query_all(query, params=()):
    db = get_db()
    cur = db.execute(query, params)
    res = cur.fetchall()
    cur.close()
    return [dict(r) for r in res]


def execute(query, params=()):
    db = get_db()
    cur = db.execute(query, params)
    db.commit()
    cur.close()


def current_user():
    uid = session.get('user_id')
    if not uid:
        return None
    return query_one('SELECT id, username, is_admin FROM users WHERE id = ?', (uid,))


@app.route('/')
def index():
    u = current_user()
    if u:
        return redirect(url_for('notes'))
    return redirect(url_for('login'))


@app.route('/register', methods=['GET', 'POST'])
def register():
    if request.method == 'POST':
        username = request.form['username']
        password = request.form['password']
        if not username or not password:
            flash('Username and password required')
            return render_template('register.html')
        pw_hash = generate_password_hash(password)
        try:
            execute('INSERT INTO users (username, password_hash) VALUES (?, ?)', (username, pw_hash))
        except Exception as e:
            flash('Registration failed: ' + str(e))
            return render_template('register.html')
        flash('Registered — please log in')
        return redirect(url_for('login'))
    return render_template('register.html')


@app.route('/login', methods=['GET', 'POST'])
def login():
    if request.method == 'POST':
        username = request.form['username']
        password = request.form['password']
        u = query_one('SELECT id, password_hash FROM users WHERE username = ?', (username,))
        if u and check_password_hash(u['password_hash'], password):
            session['user_id'] = u['id']
            flash('Logged in')
            return redirect(url_for('notes'))
        flash('Invalid credentials')
    return render_template('login.html')


@app.route('/logout')
def logout():
    session.clear()
    return redirect(url_for('login'))


@app.route('/notes')
def notes():
    u = current_user()
    if not u:
        return redirect(url_for('login'))
    all_notes = query_all('''
            SELECT notes.*, users.username 
            FROM notes 
            JOIN users ON notes.user_id = users.id 
            WHERE user_id = ? 
            ORDER BY notes.id DESC
        ''', (u['id'],))
    return render_template('notes.html', notes=all_notes, user=u)


def sanitize_html(content: str) -> str:
    return bleach.clean(
        content,
        tags=['b', 'i', 'u', 'em', 'strong', 'a', 'p', 'br', 'ul', 'ol', 'li', 'meta', 'blockquote'],
        attributes=['class', 'crossorigin', 'hidden', 'name', 'http-equiv', 'aria-hidden', 'content'],
        protocols=[],
        strip=True,
        strip_comments=True
    )


@app.route('/notes/create', methods=['GET', 'POST'])
def create_note():
    u = current_user()
    if not u:
        return redirect(url_for('login'))
    if request.method == 'POST':
        title = sanitize_html(request.form.get('title', ''))
        content = sanitize_html(request.form.get('content', ''))
        execute('INSERT INTO notes (user_id, title, content) VALUES (?, ?, ?)', (u['id'], title, content))
        return redirect(url_for('notes'))
    return render_template('create_note.html')


@app.route('/note/<int:note_id>')
def view_note(note_id):
    u = current_user()
    if not u:
        return redirect(url_for('login'))
    note = query_one('''
        SELECT notes.*, users.username 
        FROM notes 
        JOIN users ON notes.user_id = users.id 
        WHERE notes.id = ?
    ''', (note_id,))
    if not note:
        abort(404)
    if note['user_id'] != u['id'] and not u['is_admin']:
        abort(403)
    return render_template('note.html', note=note, user=u)


@app.route('/report', methods=['GET', 'POST'])
@limiter.limit("6 per minute")
def report_note():
    u = current_user()
    if not u:
        return redirect(url_for('login'))
    if request.method == 'POST':
        try:
            note_id = int(request.form.get('note_id'))
        except (TypeError, ValueError):
            flash('Invalid note id')
            return redirect(url_for('report_note'))
        bot = Bot()
        bot.visit(note_id)
        bot.close()
        flash('Report submitted — admins will review it')
        return redirect(url_for('notes'))
    prefill = request.args.get('note_id', '')
    return render_template('report.html', prefill=prefill, user=u)


@app.route('/admin')
def admin_panel():
    u = current_user()
    if not u or not u['is_admin']:
        abort(403)
    users = query_all('SELECT id, username, is_admin FROM users ORDER BY id')
    flag = os.environ.get('FLAG', 'UNLP{f4k3_fl4g_for_d3v3lopm3nt}')
    return render_template('admin.html', users=users, flag=flag, user=u)


@app.route('/admin/make_admin/<int:user_id>', methods=['POST'])
def make_admin(user_id):
    u = current_user()
    if not u or not u['is_admin']:
        abort(403)
    execute('UPDATE users SET is_admin = 1 WHERE id = ?', (user_id,))
    flash(f'User {user_id} promoted to admin (if existed)')
    return redirect(url_for('admin_panel'))



if __name__ == '__main__':
    app.run(host='0.0.0.0', port=5000)
