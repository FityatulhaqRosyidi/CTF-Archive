#!/bin/bash

docker build -t certunlp_2025_web_drhouse .
docker run -it --rm -p5000:5000 -e FLASK_ENV=development -e ADMIN_PW=redacted -e FLAG=UNLP{f4k3_fl4g_for_d3v3lopm3nt} certunlp_2025_web_drhouse
