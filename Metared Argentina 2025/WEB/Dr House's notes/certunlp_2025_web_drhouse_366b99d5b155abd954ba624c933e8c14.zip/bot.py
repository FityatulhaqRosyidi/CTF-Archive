from selenium import webdriver
from selenium.webdriver.chrome.options import Options
import time 
import os

admin_pw = os.environ.get("ADMIN_PW", "redacted")

class Bot:
    def __init__(self):
        chrome_options = Options()
        chrome_options.add_argument("--headless")  
        chrome_options.add_argument("--disable-gpu")
        chrome_options.add_argument("--no-sandbox") 
        chrome_options.add_argument("--disable-dev-shm-usage")
        chrome_options.add_argument("--disable-extensions") 
        chrome_options.add_argument("--window-size=640x480")
        chrome_options.add_argument("--allow-running-insecure-content")
        chrome_options.add_argument("--ignore-certificate-errors")
        chrome_options.add_argument("--disable-notifications")
        chrome_options.add_argument("--test-type")
        self.driver = webdriver.Chrome(options=chrome_options)
        self.driver.set_page_load_timeout(4)
        self.driver.set_script_timeout(4)

    def visit(self, note_id):
        url = "http://127.0.0.1:5000/"
        self.driver.get(url)

        # login as admin
        self.driver.find_element("name", "username").send_keys("admin")
        self.driver.find_element("name", "password").send_keys(admin_pw)
        self.driver.find_element("css selector", "button[type='submit']").click()
        time.sleep(1)
        self.driver.get(f"{url}note/{note_id}")
        time.sleep(2)

    def close(self):
        self.driver.quit()