#!/bin/bash

docker compose up || docker-compose up
