import gevent.monkey
gevent.monkey.patch_all()

from flask import Flask, request, render_template, jsonify
from pymatgen.io.cif import CifParser
from io import StringIO
import subprocess

def create_app():
    app = Flask(__name__)

    @app.route('/')
    def index():
        return render_template('index.html')

    def waf_clean(input_text):
        blacklist = ["__name__", "BuiltinImporter", "system"]
        for word in blacklist:
            if word in input_text:
                return False
        return True

    @app.route('/parse_cif', methods=['POST'])
    def parse_cif():
        content = request.form.get('ciftext', '').strip()
        if not waf_clean(content):
            return jsonify({'error': 'WAF detect hacks attempts'}), 400

        try:
            parser = CifParser(StringIO(content))
            structure = parser.parse_structures()[0]
            cif_str = structure.to(fmt="cif")
            return jsonify({'cif': cif_str})
        except Exception as e:
            return jsonify({'error': str(e)}), 500

    return app

if __name__ == '__main__':
    app = create_app()
    app.run(debug=True, host="0.0.0.0", port=5000)
