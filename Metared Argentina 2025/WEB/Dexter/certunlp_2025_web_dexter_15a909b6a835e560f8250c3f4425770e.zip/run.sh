#!/bin/bash

docker build -t certunlp-web-dexter .
docker run -it --rm -p 1337:1337 --name certunlp-web-dexter certunlp-web-dexter