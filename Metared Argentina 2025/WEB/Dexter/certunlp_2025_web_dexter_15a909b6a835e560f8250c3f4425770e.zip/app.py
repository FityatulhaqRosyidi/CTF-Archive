from flask import Flask, request, jsonify, make_response
from flask_limiter import Limiter
from flask_limiter.util import get_remote_address
from jwt import decode, encode, exceptions
import random
import os
import time

random.seed(f"s3v4r4l_{random.randint(0, 2000)}")

app = Flask(__name__)

FLAG = os.environ.get("FLAG", "UNLP{fake_flag}")

app.secret_key = f"Rem1xKey{random.randint(0, 10**12)}"

limiter = Limiter(
    get_remote_address,
    app=app,
    default_limits=["3 per minute"],
    storage_uri="memory://"
)

@app.route('/', methods=['GET'])
@limiter.limit("3/minute")
def index():
    auth = request.headers.get('Authorization')

    if not auth:
        response = make_response(jsonify({"error": "Missing JWT token"}), 401)
        issued_at = int(time.time())
        default_payload = {
            "role": "guest",
            "iat": issued_at,
        }
        new_token = encode(default_payload, app.secret_key, algorithm='HS256')
        response.headers['WWW-Authenticate'] = f'Bearer {new_token}'
        return response

    if auth.lower().startswith("bearer "):
        jwt_token = auth.split(" ", 1)[1].strip()
    else:
        jwt_token = auth.strip()

    try:
        payload = decode(jwt_token, app.secret_key, algorithms=['HS256'])
        user = payload.get('user', '')
        role = payload.get('role', '')

        if role == 'superuser' or user.lower() == 'admin':
            return jsonify({"flag": FLAG}), 200
        else:
            return jsonify({
                "error": "Not authorized",
                "details": "valid token but insufficient privileges"
            }), 403

    except exceptions.ExpiredSignatureError:
        return jsonify({"error": "Token expired"}), 401
    except exceptions.InvalidTokenError:
        return jsonify({"error": "Invalid JWT token"}), 401

if __name__ == "__main__":
    app.run(debug=False, host="0.0.0.0", port=1337)
