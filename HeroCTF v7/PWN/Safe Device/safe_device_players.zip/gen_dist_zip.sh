#!/bin/sh
zip -r safe_device_players.zip *
