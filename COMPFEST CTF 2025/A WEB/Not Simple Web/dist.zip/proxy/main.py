import socketserver
from sys import argv
import socket
import re
import threading
from time import sleep

class ThreadedTCPServer(socketserver.ThreadingMixIn, socketserver.TCPServer):
    allow_reuse_address = True # Immediately use port that has just recently been freed

class ProxyHandler(socketserver.BaseRequestHandler):
    _buffer: bytes = b""
    _timeout: int = 60

    def handle(self):
        _socket: socket.socket = self.request

        request: tuple[str, str, str] = self._get_request()
        headers: list[tuple[str, str]] = self._get_headers()

        print("Incoming request:")
        print(request)
        print(headers)

        request, headers = self._process_host(request, headers)
        request, headers = self._strip_connection(request, headers)
        request, headers, length = self._process_body_length(request, headers)
        self._filter_route(request)

        print("Outgoing request:")
        print(request)
        print(headers)
        print(length)

        self._send(request, headers, length)

    def _readbuffered(self, max_amount: int) -> bytes:
        _socket: socket.socket = self.request
        if self._timeout != 60:
            _socket.settimeout(60)

        if self._buffer == b"":
            data = _socket.recv(1024*1024)
            if data == b"":
                exit(1)
            self._buffer += data

        ret_val = self._buffer[:max_amount]
        self._buffer = self._buffer[max_amount:]
        return ret_val

    def _readline(self) -> bytes:
        data: bytes = b""
        while data[-2:] != b"\r\n":
            newbyte = self._readbuffered(1)
            if newbyte == b"":
                exit(1) # Client disconnected
            data += newbyte
        return data[:-2]

    def _get_request(self) -> tuple[str, str, str]:
        try:
            request = self._readline().decode("ASCII", "strict").strip()
        except UnicodeDecodeError:
            self._reject(400, "Bad Request")

        method, target, protocol, *other = request.split(" ")
        if len(other) != 0:
            self._reject(400, "Bad Request")

        # Case sensitive
        if method not in ["POST", "GET"]:
            self._reject(501, "Not Implemented")

        # Make http lowercase (sorry for the mess)
        if target[:1] != "/":
            uri_start = target.find("/", 7)
            # If not found, then probably no uri, -1 should lowercase the whole address
            if uri_start != -1:
                target = target[:uri_start].lower() + target[uri_start:]
            else:
                target = target.lower()
        if not (target.startswith("/") or target.startswith("http://")):
            self._reject(400, "Bad Request")

        # Case sensitive
        if protocol != "HTTP/1.1":
            self._reject(501, "Not Implemented")

        return (method, target, protocol)


    def _get_headers(self) -> list[tuple[str, str]]:
        result = []

        while True:
            entry = self._readline()
            if entry == b"":
                break
            if not re.match(rb"^[\w\-]+:.*$", entry):
                self._reject(400, "Bad Request")

            try:
                key = entry[:entry.index(b":")].title().decode("ASCII", "strict")
            except UnicodeDecodeError:
                self._reject(400, "Bad Request")
            val_bytes = entry[entry.index(b":")+1:]

            # Only allow printable, tab, space, and obsolete values
            if not all([num == 0x9 or num >= 0x20 for num in val_bytes]):
                self._reject(400, "Bad Request")

            try:
                val = val_bytes.decode("ASCII", "strict").strip()
            except UnicodeDecodeError:
                self._reject(400, "Bad Request")

            result.append((key, val))

        return result

    def _process_host(self, request, headers):
        host_entries = list(filter(lambda entry: entry[1][0] == "Host", enumerate(headers)))
        if len(host_entries) != 1:
            self._reject(400, "Bad Request")
        index, header = host_entries[0]

        location = request[1]

        if location.startswith("http://"):
            # If not found, then the whole thing is origin
            origin_index = location.find("/", 7)
            if origin_index != -1:
                origin = location[:origin_index]
                location = location[origin_index:]
            else:
                origin = location
                location = "/"

            request = (request[0], location, request[2])
            headers[index] = (header[0], origin)

        return request, headers

    def _strip_connection(self, request, headers):
        headers = list(filter(lambda header: header[0] != "Connection", headers))
        return (request, headers)

    def _process_body_length(self, request, headers):
        transfer_encodings = list(filter(lambda header: header[0] == "Transfer-Encoding", headers))
        if len(transfer_encodings) > 1:
            self._reject(400, "Bad Request")
        if len(transfer_encodings) == 1:
            transfer_encoding = transfer_encodings[0]
            if transfer_encoding[1].lower() != "chunked":
                self._reject(501, "Not Implemented")
            headers = list(filter(lambda header: header[0] != "Content-Length", headers))
            return (request, headers, -1)

        content_lengths = list(filter(lambda header: header[0] == "Content-Length", headers))
        if len(content_lengths) > 1:
            self._reject(400, "Bad Request")
        if len(content_lengths) == 1:
            content_length = content_lengths[0]
            if not re.match("^[0-9]+$", content_length[1]):
                self._reject(400, "Bad Request")
            return (request, headers, int(content_length[1]))

        return (request, headers, 0)

    def _filter_route(self, request):
        assert request[1].startswith("/")
        uri = request[1]
        if not (re.match(r"^/\w+\.\w+$", uri) or uri == "/"):
            self._reject(301, "Moved Permanently", "/reject.html")
        if "secret" in uri.lower():
            self._reject(307, "Temporary Redirect", "/reject.html")

    def _send(self, request, headers, length):
        client: socket.socket = self.request
        server: socket.socket = socket.create_connection((send_addr, send_port), timeout=5)

        header_section = "\r\n".join(map(lambda entry: f"{entry[0]}: {entry[1]}", headers))
        # Send headers
        server.sendall(f"""\
{request[0]} {request[1]} {request[2]}\r\n\
{header_section}\r\n\
\r\n\
""".encode("ASCII", "strict"))

        if length >= 0:
            if length > 0:
                self._poll(client, server, length=length)
            self._poll(client, server, client_done=True)

            # Obsolete return probably
            return

        # Chunked data transfer
        while True:
            try:
                chunk_size_str = self._readline().decode("ASCII", "strict")
            except UnicodeDecodeError:
                sefl._reject(400, "Bad Request")

            # Ignore any extensions
            ext_index = chunk_size_str.find(";")
            if ext_index != -1:
                chunk_size_str = chunk_size_str[:ext_index]
            chunk_size_str = chunk_size_str.strip()

            # Chunk size is in hex
            if not re.match(r"[0-9a-fA-F]+", chunk_size_str):
                self._reject(400, "Bad Request")
            chunk_size = int(chunk_size_str, 16)

            server.sendall(chunk_size_str.encode("ASCII", "strict") + b"\r\n")

            if chunk_size == 0:
                break

            # Server might be sending data as client is sending body
            self._poll(client, server, chunk_size)
            # Should be CRLF after chunk data
            if self._readline() != b"":
                self._reject(400, "Bad Request")

            server.sendall(b"\r\n")

        # Chunked trailer section
        while True:
            header = self._readline()
            if header == b"":
                server.sendall(b"\r\n")
                break
            server.sendall(header + b"\r\n")

        self._poll(client, server, client_done=True)


    def _poll(self, client, server, length: int = 0, client_done: bool = False):
        assert (length > 0 and not client_done) or (length == 0 and client_done)
        if len(self._buffer) > 0 and length > 0:
            data = self._readbuffered(min([1024*1024, length]))
            length -= len(data)
            server.sendall(data)

        client.setblocking(False)
        server.setblocking(False)
        self._timeout = 0

        server_header_processed = False
        server_data: bytes = b""
        sleep_count = 0

        # Keep polling until no response has been made from either side
        # If either client is done sending (waiting for all server data)
        # Or client still has something to send
        while sleep_count < 60 and (client_done or length > 0):
            client_block = False

            # Read up to length remaining
            if length > 0:
                try:
                    data = client.recv(min([1024*1024, length]))
                    if data == b"":
                        exit(1)
                    length -= len(data)
                    server.sendall(data)
                except BlockingIOError:
                    client_block = True
            # Make sure client is still listening
            else:
                try:
                    if client.recv(1) == b"":
                        exit(1)
                except BlockingIOError:
                    pass


            # Read data from server
            try:
                data = server.recv(1024*1024)
                if data == b"" and not client_done:
                    self._reject(500, "Internal Server Error")
                if data == b"" and client_done:
                    exit(0)
                # Add Connection: close header
                if not server_header_processed:
                    server_data += data
                    if b"\r\n\r\n" in server_data:
                        processed_data = self._process_server_header(server_data)
                        client.sendall(processed_data)
                    server_header_processed = True
                else:
                    client.sendall(data)
            except BlockingIOError:
                if client_block or length == 0:
                    sleep_count += 1
                    sleep(1)

    def _process_server_header(self, server_data: bytes):
        assert b"\r\n\r\n" in server_data
        header_data: bytes = server_data[:server_data.find(b"\r\n\r\n")]
        body_data: bytes = server_data[server_data.find(b"\r\n\r\n")+4:]
        header_entries = header_data.split(b"\r\n")

        processed_data: bytes = b""
        for header_entry in header_entries:
            if not re.match(rb"^connection:.*$", header_entry.lower()):
                processed_data += header_entry + b"\r\n"
            else:
                continue
        processed_data += b"Connection: close\r\n\r\n"
        processed_data += body_data
        return processed_data


    def _reject(self, code: int, reason: str, location: str|None = None):
        assert re.match(r"^[\w\- \t]+$", reason)
        assert 100 <= code <= 999
        if location is None:
            location_header = ""
        else:
            assert re.match(r"^/\w+\.\w+$", location)
            location_header = f"Location: {location}\r\n"
        _socket: socket.socket = self.request
        _socket.sendall(f"""\
HTTP/1.1 {code} {reason}\r\n\
Server: sigmaproxy/0.1
Connection: close\r\n\
{location_header}\
\r\n\
""".encode("ASCII", "strict"))
        _socket.close()
        print(code, reason)
        exit(1)


if __name__ == "__main__":
    if len(argv) < 3:
        print("Need port to listen and to send")
        exit(1)

    listen: str = argv[1]
    send: str = argv[2]

    assert re.match(r"^[\w\.-]+:[0-9]+$", listen)
    assert re.match(r"^[\w\.-]+:[0-9]+$", send)

    print(f"Listening on {listen}")
    print(f"Sending to {send}")
    listen_addr: str = listen[:listen.index(":")]
    listen_port: int = int(listen[listen.index(":")+1:])

    send_addr: str = send[:send.index(":")]
    send_port: int = int(send[send.index(":")+1:])

    with ThreadedTCPServer((listen_addr, listen_port), ProxyHandler) as server:
        server_thread = threading.Thread(target=server.serve_forever)
        # Exit the server thread when the main thread terminates
        server_thread.daemon = True
        server_thread.start()

        while True:
            pass
