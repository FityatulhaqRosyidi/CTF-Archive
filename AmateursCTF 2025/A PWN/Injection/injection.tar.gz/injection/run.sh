#!/bin/sh

cp /lib/x86_64-linux-gnu/ld-linux-x86-64.so.2 /tmp
cp /lib/x86_64-linux-gnu/libc.so.6 /tmp
cd /tmp
/app/chal