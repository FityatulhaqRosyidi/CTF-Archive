#!/bin/sh

java -Xverify:none -Xint Main
