
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <stdint.h>

#define MAX_PAYLOAD 90

static int contains_badchar(const unsigned char *buf, size_t len) {
    for (size_t i = 0; i < len; ++i) {
        unsigned char b = buf[i];
        if (b == 0x0a || b == 0x0d || b == 0x2f || b == 0xff ||
            b == 0x0f || b == 0x05 || b == 0x68) return 1;
        if (b >= 0x40 && b <= 0x81) return 1;
    }
    return 0;
}

int main(void) {
    unsigned char shellbuf[MAX_PAYLOAD + 1];
    size_t readlen = 0;
    fwrite("Stake your soul!\n", 1, 17, stdout);
    fflush(stdout);

    readlen = fread(shellbuf, 1, MAX_PAYLOAD, stdin);
    if (readlen == 0) {
        fwrite("bad soul", 1, 9, stdout);
        return 1;
    }

    if (readlen > MAX_PAYLOAD || contains_badchar(shellbuf, readlen)) {
        fwrite("bad soul", 1, 9, stdout);
        return 1;
    }

    shellbuf[readlen] = 0x00;

    ((void(*)())shellbuf)();

    return 0;
}

