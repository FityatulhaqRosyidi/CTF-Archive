#include <stdio.h>
#include <string.h>
#include <stdlib.h>

void store_pin_indb(char* pin) {
    printf("[db] PIN stored (masked): %.3s***\n", pin);
    fflush(stdout);
}

void validate_account(char* account) {
    printf("SecureBank: checking account '%s'...\n", account);
    fflush(stdout);
}

void validate_pin(char* pin) {
    char pin_buf[11];
    unsigned char pin_len = strlen(pin); 
    if(pin_len >= 4 && pin_len <= 8) {   
        printf("PIN Accepted\n");        
        fflush(stdout);
        strcpy(pin_buf, pin);            
    } else {
        printf("Invalid PIN\n");         
        fflush(stdout);
    }
    store_pin_indb(pin_buf);            
}

int main(int argc, char* argv[]) {
    char account[128];
    char pin[128];

    printf("========== Welcome to SecureBank ==========\n");
    printf("Please enter your account name and PIN (each on a new line):\n");
    fflush(stdout);

    if(!fgets(account, sizeof(account), stdin)) {
        fprintf(stderr, "No account provided. Exiting.\n");
        return 1;
    }
    account[strcspn(account, "\r\n")] = 0;

    if(!fgets(pin, sizeof(pin), stdin)) {
        fprintf(stderr, "No PIN provided. Exiting.\n");
        return 1;
    }
    pin[strcspn(pin, "\r\n")] = 0;

    validate_account(account);
    validate_pin(pin);

    printf("Thank you for using SecureBank. Goodbye.\n");
    fflush(stdout);

    return 0;
}

